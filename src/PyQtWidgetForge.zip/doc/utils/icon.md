# 图标工具

PyQtWidgetForge图标工具提供了加载和管理SVG图标的功能，让你能轻松在应用中使用高质量的图标。

## 图标集

PyQtWidgetForge内置了多个开源图标集，包括：

1. [Feather图标集](https://feathericons.com/) - 提供超过280个简洁美观的SVG图标
2. [Bootstrap图标集](https://icons.getbootstrap.com/) - 提供超过2000个流行的SVG图标

所有图标都集成在一个统一的命名空间中，您无需关心图标来自哪个图标集，可以直接通过名称使用任何图标。

## 基本用法

### 导入图标工具

```python
from PyQtWidgetForge.utils import get_icon, list_icons
```

### 获取图标

```python
# 获取基本图标
icon = get_icon("home")

# 使用自定义颜色
colored_icon = get_icon("heart", color="#FF0000")

# 设置图标大小
from PyQt6.QtCore import QSize
sized_icon = get_icon("search", size=QSize(32, 32))

# 同时设置颜色和大小
custom_icon = get_icon("user", color="#3498db", size=QSize(24, 24))
```

### 列出可用图标

```python
# 获取所有可用图标的名称列表
icon_names = list_icons()
print(f"可用图标数量: {len(icon_names)}")
print(f"部分图标: {icon_names[:10]}")
```

## 在控件中使用

```python
from PyQt6.QtWidgets import QPushButton
from PyQtWidgetForge.utils import get_icon

# 创建带图标的按钮
button = QPushButton()
button.setIcon(get_icon("settings"))
button.setText("设置")
```

## 图标颜色

大多数图标默认使用黑色线条，但你可以通过`color`参数自定义颜色。颜色可以使用以下格式：

- 十六进制格式: `"#FF0000"`（红色）
- 命名颜色: `"red"`、`"blue"`等
- RGB格式: `"rgb(255, 0, 0)"`（红色）

## 浏览图标

您可以运行示例程序来浏览所有可用的图标：

```bash
# 从项目根目录运行
python example/basic/icon_browser.py
```

图标浏览器提供了搜索功能，并允许您预览不同颜色和大小的图标效果。

## 注意事项

1. 如果指定的图标不存在，`get_icon()`函数会返回一个空的QIcon对象，并在控制台输出警告信息。
2. 图标会被缓存以提高性能，相同参数的多次调用只会加载一次图标。
3. 图标存储在以下目录：
   - Feather图标：`PyQtWidgetForge/resources/icons/svg/`
   - Bootstrap图标：`PyQtWidgetForge/resources/icons/bootstrap/`
4. 如果不同图标集中存在同名图标，将按照优先级选择（Feather优先于Bootstrap）。
5. 您也可以添加自己的SVG图标到这些目录。 