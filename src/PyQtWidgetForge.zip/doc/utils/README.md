# 工具模块文档

PyQtWidgetForge工具模块提供了一系列辅助工具和实用函数，帮助开发者更轻松地使用PyQt6创建应用程序。

## 可用工具

### 图标工具

- [get_icon](./icon.md) - 获取指定名称的图标，支持颜色和大小自定义
- [list_icons](./icon.md) - 列出所有可用的图标名称

### 即将添加的工具

- 颜色工具 - 颜色转换、生成和操作函数
- 资源加载工具 - 简化资源文件的加载和管理
- 样式工具 - 辅助生成和管理样式表
- 布局工具 - 简化复杂布局的创建

## 使用方式

工具模块可以通过以下方式导入：

```python
# 导入整个工具模块
from PyQtWidgetForge import utils

# 直接导入特定工具函数
from PyQtWidgetForge.utils import get_icon, list_icons
```

## 示例说明

查看[图标浏览器示例](../../example/utils/icon_browser.py)可以了解如何使用图标工具函数。

```python
# 基本使用示例
from PyQtWidgetForge.utils import get_icon, list_icons
from PyQt6.QtCore import QSize

# 获取图标
icon = get_icon("search")

# 获取自定义颜色和大小的图标
colored_icon = get_icon("heart", color="#FF0000", size=QSize(32, 32))

# 获取所有可用图标名称
all_icons = list_icons()
``` 