# 控件模块文档

PyQtWidgetForge控件模块提供了一系列美观、现代化的UI控件，这些控件可以直接应用于各种PyQt6应用程序中。

## 可用控件

### 窗口类

- [Window](./window.md) - 支持主题切换的主窗口组件，提供深色/浅色主题和主题颜色设置

### 按钮类

- [Button](./button.md) - 基础按钮类，其他所有按钮类型的基类
- NormalButton - 标准按钮
- PrimaryButton - 主要按钮，通常用于强调主要操作
- FlatButton - 扁平风格按钮
- LinkButton - 链接风格按钮
- InfoButton - 信息类型按钮
- GlowButton - 带发光效果的按钮
- IconButton - 带图标的按钮变种（各类按钮均有对应的带图标版本）
- RoundButton - 圆形按钮
- ToggleButton - 可切换状态的按钮

## 使用方式

控件模块可以通过以下方式导入：

```python
# 导入整个控件模块
from PyQtWidgetForge import widgets

# 直接导入特定控件
from PyQtWidgetForge.widgets import Button, Window

# 导入按钮子模块中的特定控件
from PyQtWidgetForge.widgets.button import PrimaryButton, FlatButton

# 导入窗口组件和主题模式
from PyQtWidgetForge.widgets import Window, ThemeMode
```

注意：RoundMenu已移至common.elements模块，请参考[通用元素文档](../common/elements/README.md)。

常用控件也可以直接从PyQtWidgetForge包导入：

```python
from PyQtWidgetForge import Button, Window, ThemeMode
```

## 设计理念

PyQtWidgetForge控件模块的设计理念：

1. **一致性** - 所有控件遵循统一的设计语言，使应用界面整体风格一致
2. **美观性** - 控件默认样式美观，符合现代UI设计趋势
3. **易用性** - 控件接口简单直观，易于集成和使用
4. **可定制性** - 控件提供丰富的自定义选项，可根据需要调整外观和行为
5. **性能优化** - 控件设计考虑性能因素，尽量减少资源占用 
6. **主题适应** - 支持浅色/深色主题自动切换，提升用户体验 