# ForgeButton 按钮组件

## 1. 快速上手

```python
from PyQtWidgetForge.widgets import ForgeButton

# 普通按钮（文本 + 可选图标）
btn = ForgeButton("保存", icon_name="save")

# 强调按钮（主题色背景）
primary = ForgeButton("确认", emphasized=True)

# 无边框按钮
flat = ForgeButton("更多", flat=True)

# 链接按钮
link = ForgeButton("访问官网", link=True)

# 信息按钮（内置 five-level 颜色）
info = ForgeButton("成功", level="success")

# 辉光按钮
glow = ForgeButton("高亮", glow_color="#3daee9")

# 圆角按钮
round_ = ForgeButton("标签", rounded=True)

# 可选中按钮（状态开关）
toggle = ForgeButton("Toggle", button_type="toggle")

# 下拉菜单按钮
from PyQtWidgetForge.common.elements.menu import RoundMenu
menu = RoundMenu(); menu.addAction("操作 1"); menu.addAction("操作 2")
dropdown = ForgeButton("更多…", button_type="dropdown")
dropdown.set_menu(menu)  # 与 Qt 的 setMenu 不同, 请使用此方法

# 拆分按钮（左侧点击执行操作，右侧显示菜单）
split = ForgeButton("保存", button_type="split")
split.set_menu(menu)  # 设置右侧下拉菜单

```

---

## 2. 核心参数

| 参数 | 类型 | 说明 |
|------|------|------|
| `text` | str | 按钮文本（可空） |
| `icon_name` | str \| None | 图标名称，来自内置 SVG 图标库 |
| `emphasized` | bool | 是否强调按钮（使用主题色背景） |
| `flat` | bool | 无边框按钮（透明背景，仅前景变色） |
| `link` | bool | 链接样式（蓝色文字，带下划线） |
| `level` | `"info" \| "success" \| "warning" \| "danger" \| "default"` | 信息级别按钮 |
| `rounded` | bool | 圆角按钮（16px 边角） |
| `glow_color` | str \| None | 设置辉光效果颜色（HEX） |
| `button_type` | `"basic"` `"toggle"` `"dropdown"` `"split"` | 按钮类型：普通 / 可选中 / 下拉菜单 / 拆分按钮 |

> 互斥规则：`toggle` 不可与 `emphasized/link/level` 同时出现；`rounded` 不可与 `flat/link` 同时出现；`glow` 不可与 `flat/link` 同时出现。

---

## 3. 运行时方法

| 方法 | 作用 |
|------|------|
| `set_icon_name(name:str, color:str None=None)` | 动态修改图标与颜色 |
| `set_emphasized(bool)` / `is_emphasized()` | 开关强调样式 |
| `set_flat(bool)` | 动态切换无边框 |
| `set_link(bool)` | 动态切换链接样式 |
| `set_level(str None)` | 动态切换信息级别 |
| `set_rounded(bool)` | 开关圆角 |
| `set_glow_color(str None)` | 设置/取消辉光 |
| `set_checked_color(QColor str)` | (toggle) 选中颜色 |
| `set_menu(RoundMenu)` | (dropdown/split) 绑定圆角菜单 |
| `set_split_ratio(float)` | (split) 设置拆分比例(0-1) |

所有方法均支持链式调用，且继承 Qt 原生 `QPushButton` 的全部接口。

---

## 4. 选中按钮 (Toggle)

```python
# 无边框可选中按钮，选中后文字变主题色
flat_toggle = ForgeButton(
    "过滤器", flat=True, button_type="toggle"
)
flat_toggle.setChecked(True)  # 默认选中
```

选中 / 取消选中均使用平滑颜色动画；背景始终透明。

---

## 5. 下拉菜单 (Dropdown)

```python
menu = RoundMenu(); menu.addAction("刷新"); menu.addAction("删除")

drop = ForgeButton(
    "操作",
    icon_name="chevron-down",
    button_type="dropdown",
)
drop.set_menu(menu)
```

`ForgeButton` 会自动在右侧绘制箭头，并处理点击/右键弹出 `RoundMenu`。

---

## 6. 拆分按钮 (Split)

```python
menu = RoundMenu(); menu.addAction("另存为"); menu.addAction("导出...")

split = ForgeButton(
    "保存", 
    icon_name="save",
    button_type="split"
)
split.set_menu(menu)
split.set_split_ratio(0.7)  # 可选：设置左右分割比例，默认0.75
```

拆分按钮由左右两部分组成，中间有一条分隔线：
- 点击左侧部分，触发按钮的 `clicked` 信号
- 点击右侧部分，弹出下拉菜单
- 鼠标悬停/点击时，左右两部分有独立的视觉反馈