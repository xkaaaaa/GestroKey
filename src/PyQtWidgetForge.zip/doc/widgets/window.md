# 窗口组件 (Window)

窗口组件是PyQtWidgetForge提供的支持主题设置和管理的主窗口控件。它继承自Qt的QMainWindow，提供与原生窗口相同的功能，同时增加了主题切换和样式管理功能。

## 主要特点

- **主题切换**：支持自动（跟随系统）、浅色和深色三种主题模式
- **主题颜色**：支持自定义主题强调色，影响按钮和其他UI元素
- **全局设置**：主题设置全局生效，所有兼容组件自动适应
- **实时切换**：主题变更实时反映到所有支持的组件上
- **API简单**：简单易用的API，方便集成和使用
- **原生兼容**：完全兼容QMainWindow的所有功能和方法

## 主题模式

PyQtWidgetForge的Window组件支持三种主题模式：

1. **自动（跟随系统）**：默认模式，尝试检测系统主题并自动选择对应的主题
2. **浅色主题**：强制使用浅色主题，忽略系统设置
3. **深色主题**：强制使用深色主题，忽略系统设置

## 使用方法

### 创建窗口

```python
from PyQtWidgetForge.widgets import Window, ThemeMode
from PyQt6.QtGui import QColor

# 简单的窗口创建，使用默认主题设置
window = Window(title="我的应用", width=800, height=600)
window.show()

# 创建使用深色主题的窗口
dark_window = Window(
    title="深色主题应用",
    width=800,
    height=600,
    theme_mode=ThemeMode.DARK
)
dark_window.show()

# 创建带自定义主题颜色的窗口
colored_window = Window(
    title="自定义颜色应用",
    width=800,
    height=600,
    theme_color=QColor("#FF5733")  # 设置橙红色为主题色
)
colored_window.show()
```

### 动态切换主题

```python
# 获取窗口实例
window = Window(title="我的应用")

# 切换到深色主题
window.set_theme_mode(ThemeMode.DARK)

# 切换到浅色主题
window.set_theme_mode(ThemeMode.LIGHT)

# 切换到自动模式（跟随系统）
window.set_theme_mode(ThemeMode.AUTO)

# 更改主题颜色
window.set_theme_color(QColor(61, 174, 233))  # 蓝色
window.set_theme_color(QColor("#FF5733"))     # 橙红色
```

### 获取主题信息

```python
# 获取当前主题模式
current_mode = window.get_theme_mode()  # 返回ThemeMode枚举值

# 判断当前是否为深色模式
is_dark = window.is_dark_mode()  # 返回布尔值

# 获取当前主题颜色
current_color = window.get_theme_color()  # 返回QColor对象
```

### 监听主题变更

```python
class MyWindow(Window):
    def __init__(self):
        super().__init__(title="主题监听示例")
        
        # 连接主题变更信号
        self.theme_changed.connect(self.on_theme_changed)
        
    def on_theme_changed(self, is_dark):
        # is_dark参数指示变更后是否为深色模式
        print(f"主题已变更为: {'深色' if is_dark else '浅色'}")
        
        # 执行一些主题相关的自定义逻辑
        if is_dark:
            # 深色主题下的特殊处理
            pass
        else:
            # 浅色主题下的特殊处理
            pass
```

### 完全控制窗口

Window组件完全兼容QMainWindow的所有功能和方法，您可以像使用QMainWindow一样使用它：

```python
from PyQtWidgetForge.widgets import Window

class MainWindow(Window):
    def __init__(self):
        super().__init__(title="完整窗口示例")
        
        # 创建中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 添加菜单栏
        menu_bar = self.menuBar()
        file_menu = menu_bar.addMenu("文件")
        edit_menu = menu_bar.addMenu("编辑")
        
        # 添加工具栏
        toolbar = self.addToolBar("主工具栏")
        toolbar.addAction("新建")
        toolbar.addAction("打开")
        
        # 添加状态栏
        self.statusBar().showMessage("就绪")
        
        # 添加停靠部件
        dock = QDockWidget("工具箱", self)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, dock)
```

## 全局主题管理

除了通过Window实例管理主题外，您还可以直接使用ThemeManager单例来全局管理主题：

```python
from PyQtWidgetForge.widgets import ThemeManager, ThemeMode
from PyQt6.QtGui import QColor

# 获取主题管理器实例
theme_manager = ThemeManager.instance()

# 设置主题模式
theme_manager.set_theme_mode(ThemeMode.DARK)

# 设置主题颜色
theme_manager.set_theme_color(QColor("#FF5733"))

# 获取当前主题信息
current_mode = theme_manager.get_theme_mode()
is_dark = theme_manager.is_dark_mode()
current_color = theme_manager.get_theme_color()

# 监听主题变更
theme_manager.theme_changed.connect(on_theme_changed)
```

## 与原生Qt组件的差异

Window组件继承自QMainWindow，但添加了以下额外功能：

1. 内置主题支持，包括浅色/深色模式和主题颜色设置
2. 提供theme_changed信号，用于监听主题变更
3. 提供主题管理API，如set_theme_mode、set_theme_color等
4. 自动应用主题到所有支持的子组件

其余功能与QMainWindow完全一致。

## API参考

### Window类

#### 构造函数

```python
Window(parent=None, title="PyQtWidgetForge Window", width=800, height=600, 
       theme_mode=None, theme_color=None)
```

- **parent**: 父组件
- **title**: 窗口标题
- **width**: 窗口宽度
- **height**: 窗口高度
- **theme_mode**: 主题模式，None表示使用全局设置
- **theme_color**: 主题颜色，None表示使用全局设置

#### 方法

| 方法 | 说明 |
|-----|-----|
| get_theme_mode() | 获取当前主题模式，返回ThemeMode枚举值 |
| set_theme_mode(mode) | 设置主题模式，mode为ThemeMode枚举值 |
| get_theme_color() | 获取当前主题颜色，返回QColor对象 |
| set_theme_color(color) | 设置主题颜色，color为QColor对象 |
| is_dark_mode() | 判断当前是否为深色模式，返回布尔值 |

#### 信号

| 信号 | 说明 |
|-----|-----|
| theme_changed(bool) | 主题变更信号，参数为变更后是否为深色模式 |

### ThemeMode枚举

```python
class ThemeMode(Enum):
    AUTO = 0    # 自动（跟随系统）
    LIGHT = 1   # 浅色主题
    DARK = 2    # 深色主题
```

### ThemeManager类

这是一个单例类，用于全局管理主题设置。

#### 获取实例

```python
manager = ThemeManager.instance()
```

#### 方法

| 方法 | 说明 |
|-----|-----|
| get_theme_mode() | 获取当前主题模式，返回ThemeMode枚举值 |
| set_theme_mode(mode) | 设置主题模式，mode为ThemeMode枚举值 |
| get_theme_color() | 获取当前主题颜色，返回QColor对象 |
| set_theme_color(color) | 设置主题颜色，color为QColor对象 |
| is_dark_mode() | 判断当前是否为深色模式，返回布尔值 |
| refresh() | 刷新主题设置，在系统主题变更时调用 |
| get_themed_color(light_color, dark_color=None) | 根据当前主题获取适合的颜色 |

#### 信号

| 信号 | 说明 |
|-----|-----|
| theme_changed() | 主题变更信号 |

## 注意事项

1. Window组件首次实例化时会自动使用Fusion样式（如QApplication尚未设置样式）。
2. 主题变更将应用到整个应用程序，不仅仅是当前窗口。
3. 自动主题检测功能的准确性取决于操作系统和Qt版本。
4. 主题设置会保存到QSettings中，下次应用启动时会自动恢复。
5. 如果您的应用程序已经设置了自定义样式表，可能会与Window组件的主题功能产生冲突。 