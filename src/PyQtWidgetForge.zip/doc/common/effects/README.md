# 特效模块

PyQtWidgetForge特效模块提供了一系列可用于增强UI视觉效果的特效组件，使应用界面更加现代化和专业化。

## 可用特效

- [AnimatedShadowEffect](./shadow.md) - 可动画化的阴影效果，支持多种状态间的平滑过渡

即将提供的特效：
- 发光特效 (Glow) - 为组件添加柔和的外发光效果
- 渐变特效 (Gradient) - 为组件添加线性或径向渐变背景
- 玻璃特效 (Glass) - 为组件添加毛玻璃/磨砂玻璃效果
- 波纹特效 (Ripple) - 为组件添加点击波纹动画效果

## 使用方式

特效模块可以通过以下方式导入：

```python
# 导入特效模块
from PyQtWidgetForge.common import effects

# 导入具体特效
from PyQtWidgetForge.common.effects import AnimatedShadowEffect
```

## 注意事项

- 某些特效可能会对性能产生影响，尤其是在低配置设备上
- 特效通常可以组合使用，但过多的特效叠加可能导致视觉混乱 