# AnimatedShadowEffect - 动画阴影效果

`AnimatedShadowEffect`类提供了一个可动画化的阴影效果，让控件在不同状态之间的阴影变化更加平滑自然。

## 特性

- 预定义多种阴影状态（正常、悬停、按下、禁用）
- 支持自定义阴影状态
- 阴影参数（偏移、模糊半径、颜色）的平滑过渡
- 易于集成到任何QWidget组件中

## 初始化

```python
from PyQtWidgetForge.common.effects import AnimatedShadowEffect

# 创建按钮
button = QPushButton("点击我")

# 创建并应用阴影效果
shadow_effect = AnimatedShadowEffect(button)
```

## 方法说明

### set_state

设置阴影状态，可以是预定义状态或自定义状态。

```python
def set_state(self, state_name, animate=True):
```

参数:
- `state_name` (str): 状态名称，预定义有"normal"、"hover"、"pressed"、"disabled"
- `animate` (bool): 是否使用动画过渡，默认为True

### set_custom_state

添加自定义阴影状态。

```python
def set_custom_state(self, state_name, offset, blur_radius, color):
```

参数:
- `state_name` (str): 自定义状态名称
- `offset` (float): 阴影偏移量
- `blur_radius` (float): 阴影模糊半径
- `color` (QColor): 阴影颜色

### set_animation_duration

设置状态切换时的动画持续时间。

```python
def set_animation_duration(self, duration):
```

参数:
- `duration` (int): 动画持续时间，单位毫秒

### get_current_state

获取当前阴影状态的名称。

```python
def get_current_state(self):
```

返回:
- 当前状态名称字符串

### stop_animations

停止所有正在进行的阴影动画。

```python
def stop_animations(self):
```

## 预定义状态说明

`AnimatedShadowEffect`预定义了以下状态：

| 状态名称 | 说明 | 默认偏移 | 默认模糊半径 | 默认颜色 |
| --- | --- | --- | --- | --- |
| normal | 正常状态 | 2.0 | 6.0 | rgba(0,0,0,40) |
| hover | 悬停状态 | 3.0 | 8.0 | rgba(0,0,0,50) |
| pressed | 按下状态 | 1.0 | 4.0 | rgba(0,0,0,60) |
| disabled | 禁用状态 | 1.0 | 3.0 | rgba(0,0,0,20) |

## 使用示例

### 基本用法

```python
from PyQt6.QtWidgets import QApplication, QPushButton
from PyQt6.QtCore import QSize
from PyQtWidgetForge.common.effects import AnimatedShadowEffect

# 创建应用程序
app = QApplication([])

# 创建按钮
button = QPushButton("带阴影按钮")
button.setFixedSize(150, 50)

# 创建并应用阴影效果
shadow = AnimatedShadowEffect(button)

# 连接事件
button.enterEvent = lambda e: shadow.set_state("hover")
button.leaveEvent = lambda e: shadow.set_state("normal")
button.mousePressEvent = lambda e: shadow.set_state("pressed")
button.mouseReleaseEvent = lambda e: shadow.set_state("hover" if button.rect().contains(e.pos()) else "normal")

# 显示按钮
button.show()

# 启动应用程序事件循环
app.exec()
```

### 自定义阴影状态

```python
from PyQt6.QtWidgets import QApplication, QPushButton
from PyQt6.QtCore import QSize, QTimer
from PyQt6.QtGui import QColor
from PyQtWidgetForge.common.effects import AnimatedShadowEffect

# 创建应用程序
app = QApplication([])

# 创建按钮
button = QPushButton("自定义阴影")
button.setFixedSize(200, 60)

# 创建并应用阴影效果
shadow = AnimatedShadowEffect(button)

# 添加自定义阴影状态
shadow.set_custom_state("highlight", 5.0, 15.0, QColor(0, 120, 215, 80))
shadow.set_custom_state("subtle", 1.5, 5.0, QColor(0, 0, 0, 30))

# 设置较长的动画时间
shadow.set_animation_duration(500)

# 创建状态循环
states = ["normal", "highlight", "subtle", "hover"]
current_index = 0

def change_state():
    global current_index
    current_index = (current_index + 1) % len(states)
    shadow.set_state(states[current_index])
    button.setText(f"状态: {states[current_index]}")

# 设置定时器每2秒切换一次状态
timer = QTimer()
timer.timeout.connect(change_state)
timer.start(2000)

# 显示按钮
button.show()

# 启动应用程序事件循环
app.exec()
```

## 注意事项

- 应用阴影效果会覆盖控件已有的图形效果，每个控件同时只能应用一种图形效果
- 大量使用动画阴影效果可能对性能有所影响，尤其是在低配置设备上
- 为了获得最佳效果，控件应该有足够的外边距来显示阴影 