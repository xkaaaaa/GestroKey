# 通用组件模块文档

PyQtWidgetForge的通用组件模块提供了一系列可在多个组件中复用的功能、特效和元素，帮助开发者快速构建一致性强、视觉效果佳的界面。

## 模块结构

- [**动画 (Animations)**](./animations/README.md) - 提供平滑的UI过渡动画效果
- [**特效 (Effects)**](./effects/README.md) - 提供各种视觉特效，如发光、阴影等
- [**元素 (Elements)**](./elements/README.md) - 提供可在多个组件中复用的基础UI元素

- 注意：与其您仔细地阅读文档以知晓使用方法，不如运行example/launcher.py。

## 使用方式

通用模块可以通过PyQtWidgetForge的common包直接导入使用：

```python
# 导入整个模块
from PyQtWidgetForge import common

# 直接导入特定功能
from PyQtWidgetForge.common.animations import SmoothTransition
from PyQtWidgetForge.common.effects import ...
from PyQtWidgetForge.common.elements import ...
```

常用的通用功能也可以直接从PyQtWidgetForge包导入：

```python
from PyQtWidgetForge import SmoothTransition
```