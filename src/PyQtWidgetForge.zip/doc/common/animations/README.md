# 动画模块

PyQtWidgetForge通用动画模块提供了一系列可用于各种组件的平滑动画效果，让界面元素的状态变化更加自然流畅。

## 可用动画

- [SmoothTransition](./smooth_transition.md) - 平滑过渡动画，支持属性值、位置、大小、透明度、颜色等多种属性的平滑变换 