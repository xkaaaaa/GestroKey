# SmoothTransition - 平滑过渡动画

`SmoothTransition`类提供对控件属性的平滑过渡动画效果，支持多种属性类型和缓动曲线，使UI元素的状态变化更加自然流畅。

## 特性

- 支持多种属性类型的动画（位置、大小、透明度、颜色、阴影等）
- 使用缓动曲线实现平滑的非线性变化
- 支持自定义缓动曲线（三次贝塞尔曲线）
- 内置多种常用动画效果（淡入淡出、滑动、大小变化等）
- 支持动画完成后的回调函数
- 自动管理动画生命周期

## 初始化

```python
from PyQtWidgetForge.common.animations import SmoothTransition

# 创建动画对象
transition = SmoothTransition()
```

## 方法说明

### 基础方法

#### animate

创建并启动属性动画。

```python
def animate(self, target, property_name, start_value, end_value, duration=300, 
            easing_curve=QEasingCurve.Type.OutCubic, finished_callback=None):
```

参数:
- `target` (QObject): 目标控件或对象
- `property_name` (str/bytes): 要动画的属性名称
- `start_value`: 起始值
- `end_value`: 结束值
- `duration` (int): 动画持续时间，单位毫秒
- `easing_curve` (QEasingCurve.Type): 缓动曲线类型
- `finished_callback` (callable): 动画完成时的回调函数

返回:
- `QPropertyAnimation`: 创建的动画对象

#### stop_all

停止所有动画。

```python
def stop_all(self):
```

### 内置动画效果

#### fade

淡入淡出动画。

```python
def fade(self, widget, start_opacity, end_opacity, duration=300, 
         easing_curve=QEasingCurve.Type.OutCubic, finished_callback=None):
```

参数:
- `widget` (QWidget): 目标控件
- `start_opacity` (float): 起始透明度 (0.0-1.0)
- `end_opacity` (float): 结束透明度 (0.0-1.0)
- `duration` (int): 动画持续时间，单位毫秒
- `easing_curve` (QEasingCurve.Type): 缓动曲线类型
- `finished_callback` (callable): 动画完成时的回调函数

#### slide

滑动动画。

```python
def slide(self, widget, start_pos, end_pos, duration=300,
          easing_curve=QEasingCurve.Type.OutCubic, finished_callback=None):
```

参数:
- `widget` (QWidget): 目标控件
- `start_pos` (QPoint): 起始位置
- `end_pos` (QPoint): 结束位置
- `duration` (int): 动画持续时间，单位毫秒
- `easing_curve` (QEasingCurve.Type): 缓动曲线类型
- `finished_callback` (callable): 动画完成时的回调函数

#### resize

大小调整动画。

```python
def resize(self, widget, start_size, end_size, duration=300,
           easing_curve=QEasingCurve.Type.OutCubic, finished_callback=None):
```

参数:
- `widget` (QWidget): 目标控件
- `start_size` (QSize): 起始大小
- `end_size` (QSize): 结束大小
- `duration` (int): 动画持续时间，单位毫秒
- `easing_curve` (QEasingCurve.Type): 缓动曲线类型
- `finished_callback` (callable): 动画完成时的回调函数

#### geometry_change

几何变化动画（同时改变位置和大小）。

```python
def geometry_change(self, widget, start_rect, end_rect, duration=300,
                   easing_curve=QEasingCurve.Type.OutCubic, finished_callback=None):
```

参数:
- `widget` (QWidget): 目标控件
- `start_rect` (QRect): 起始矩形区域
- `end_rect` (QRect): 结束矩形区域
- `duration` (int): 动画持续时间，单位毫秒
- `easing_curve` (QEasingCurve.Type): 缓动曲线类型
- `finished_callback` (callable): 动画完成时的回调函数

#### color_change

颜色变化动画。

```python
def color_change(self, obj, property_name, start_color, end_color, duration=300,
                easing_curve=QEasingCurve.Type.OutCubic, finished_callback=None):
```

参数:
- `obj` (QObject): 目标对象
- `property_name` (str): 要动画的属性名称
- `start_color` (QColor): 起始颜色
- `end_color` (QColor): 结束颜色
- `duration` (int): 动画持续时间，单位毫秒
- `easing_curve` (QEasingCurve.Type): 缓动曲线类型
- `finished_callback` (callable): 动画完成时的回调函数

#### point_change

点位置变化动画。

```python
def point_change(self, obj, property_name, start_point, end_point, duration=300,
                easing_curve=QEasingCurve.Type.OutCubic, finished_callback=None):
```

参数:
- `obj` (QObject): 目标对象
- `property_name` (str): 要动画的属性名称
- `start_point` (QPoint/QPointF): 起始点位置
- `end_point` (QPoint/QPointF): 结束点位置
- `duration` (int): 动画持续时间，单位毫秒
- `easing_curve` (QEasingCurve.Type): 缓动曲线类型
- `finished_callback` (callable): 动画完成时的回调函数

#### path_change

路径变化动画。

```python
def path_change(self, obj, property_name, start_path, end_path, duration=300,
               easing_curve=QEasingCurve.Type.OutCubic, finished_callback=None):
```

参数:
- `obj` (QObject): 目标对象
- `property_name` (str): 要动画的属性名称
- `start_path` (QPainterPath): 起始路径
- `end_path` (QPainterPath): 结束路径
- `duration` (int): 动画持续时间，单位毫秒
- `easing_curve` (QEasingCurve.Type): 缓动曲线类型
- `finished_callback` (callable): 动画完成时的回调函数

#### shadow_offset_change

阴影偏移变化动画。

```python
def shadow_offset_change(self, effect, start_offset, end_offset, duration=300,
                        easing_curve=QEasingCurve.Type.OutCubic, finished_callback=None):
```

参数:
- `effect` (QGraphicsDropShadowEffect): 阴影效果对象
- `start_offset` (float/QPointF): 起始偏移
- `end_offset` (float/QPointF): 结束偏移
- `duration` (int): 动画持续时间，单位毫秒
- `easing_curve` (QEasingCurve.Type): 缓动曲线类型
- `finished_callback` (callable): 动画完成时的回调函数

#### shadow_blur_change

阴影模糊半径变化动画。

```python
def shadow_blur_change(self, effect, start_blur, end_blur, duration=300,
                      easing_curve=QEasingCurve.Type.OutCubic, finished_callback=None):
```

参数:
- `effect` (QGraphicsDropShadowEffect): 阴影效果对象
- `start_blur` (float): 起始模糊半径
- `end_blur` (float): 结束模糊半径
- `duration` (int): 动画持续时间，单位毫秒
- `easing_curve` (QEasingCurve.Type): 缓动曲线类型
- `finished_callback` (callable): 动画完成时的回调函数

### 缓动曲线工具

#### get_easing_curve

获取缓动曲线对象。

```python
@staticmethod
def get_easing_curve(curve_type=QEasingCurve.Type.OutCubic):
```

参数:
- `curve_type` (QEasingCurve.Type): 缓动曲线类型

返回:
- `QEasingCurve`: 缓动曲线对象

#### cubic_bezier

创建自定义三次贝塞尔曲线。

```python
@staticmethod
def cubic_bezier(x1, y1, x2, y2):
```

参数:
- `x1`, `y1`: 第一个控制点
- `x2`, `y2`: 第二个控制点

返回:
- `QEasingCurve`: 自定义缓动曲线

## 使用示例

### 基本使用示例

```python
from PyQt6.QtWidgets import QApplication, QWidget, QPushButton
from PyQt6.QtCore import QPoint, QSize, Qt
from PyQt6.QtGui import QColor
from PyQtWidgetForge.common.animations import SmoothTransition

# 创建应用程序
app = QApplication([])

# 创建窗口
window = QWidget()
window.setWindowTitle("动画示例")
window.resize(400, 300)

# 创建按钮
button = QPushButton("点击我", window)
button.resize(100, 30)
button.move(150, 130)

# 创建动画管理器
transition = SmoothTransition()

# 定义点击处理函数
def on_button_clicked():
    # 创建几何变化动画
    transition.geometry_change(button, 
                              button.geometry(), 
                              QRect(250, 130, 150, 50), 
                              duration=500)

# 连接按钮点击信号
button.clicked.connect(on_button_clicked)

# 显示窗口
window.show()

# 启动应用程序事件循环
app.exec()
```

### 按钮动画示例

```python
from PyQt6.QtWidgets import QApplication, QGraphicsDropShadowEffect
from PyQt6.QtCore import QPointF
from PyQt6.QtGui import QColor
from PyQtWidgetForge.common.animations import SmoothTransition

# 为按钮添加动画效果
class AnimatedButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        
        # 创建动画管理器
        self.transition = SmoothTransition(self)
        
        # 创建阴影效果
        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(5)
        self.shadow.setColor(QColor(0, 0, 0, 60))
        self.shadow.setOffset(0, 2)
        self.setGraphicsEffect(self.shadow)
        
        # 连接事件
        self.pressed.connect(self.on_pressed)
        self.released.connect(self.on_released)
        
    def on_pressed(self):
        # 阴影效果动画
        self.transition.shadow_offset_change(self.shadow, 2, 1, 100)
        self.transition.shadow_blur_change(self.shadow, 5, 3, 100)
        
        # 颜色变化动画
        self.transition.color_change(self, "color", self.palette().button().color(),
                                   QColor(180, 180, 180), 100)
                                   
        # 内容位移动画
        self.transition.point_change(self, "contentOffset", QPointF(0, 0), QPointF(0, 2), 100)
        
    def on_released(self):
        # 阴影效果动画
        self.transition.shadow_offset_change(self.shadow, 1, 2, 200)
        self.transition.shadow_blur_change(self.shadow, 3, 5, 200)
        
        # 颜色变化动画
        self.transition.color_change(self, "color", QColor(180, 180, 180),
                                   self.palette().button().color(), 200)
                                   
        # 内容位移动画
        self.transition.point_change(self, "contentOffset", QPointF(0, 2), QPointF(0, 0), 200)
```

## 注意事项

- 动画对象会自动跟踪和清理完成的动画，但在某些情况下可能需要手动调用`stop_all()`来停止所有动画（例如窗口关闭时）
- 要动画的对象属性必须使用Qt的属性系统，或者通过`pyqtProperty`定义
- 当创建多个连续动画时，建议使用回调函数而不是连续调用，以确保动画按顺序执行
- 对于阴影效果动画，需要先创建QGraphicsDropShadowEffect对象，再使用shadow_offset_change和shadow_blur_change方法 