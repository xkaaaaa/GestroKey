# 通用元素模块文档

PyQtWidgetForge通用元素模块提供了可用于多个组件的基础UI元素，这些元素可以应用于各种场景和控件中。

## 可用元素

### 菜单元素

- [RoundMenu](./menu.md) - 圆角菜单元素，可用于下拉菜单、右键菜单等场景

## 使用方式

通用元素可以通过以下方式导入：

```python
# 导入特定元素
from PyQtWidgetForge.common.elements import RoundMenu

# 直接从具体模块导入
from PyQtWidgetForge.common.elements.menu import RoundMenu
```

## 设计理念

通用元素模块的设计理念：

1. **通用性** - 元素设计注重通用性，可在多种场景和组件中使用
2. **复用性** - 鼓励代码复用，减少重复实现相似功能的代码
3. **一致性** - 保持与整体设计语言一致，使应用界面整体风格统一
4. **独立性** - 元素相对独立，可单独使用而不依赖于特定控件
5. **可组合性** - 元素可以与其他组件自由组合，构建复杂界面