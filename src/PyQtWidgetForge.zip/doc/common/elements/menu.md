# 圆角菜单 (RoundMenu)

圆角菜单是一个可用于多种场景的UI元素，提供具有圆角和动画效果的美观菜单组件。

## 特性

- 美观的圆角边框设计
- 自定义圆角半径
- 可用于下拉菜单、右键菜单等多种场景
- 支持多级子菜单，子菜单项使用前导图标指示
- 平滑的显示动画效果
- 智能颜色系统，只需设置背景色，其他颜色都会自动调整
- 自动调整位置，避免超出屏幕边界
- 灵活的菜单显示位置选择（顶部/底部/左侧/右侧/中心等）
- 支持自定义菜单对齐点，精确控制菜单与目标的对齐方式

## 使用方法

### 基本用法

```python
from PyQtWidgetForge.common.elements.menu import RoundMenu

# 创建圆角菜单
menu = RoundMenu()
menu.addAction("新建文件")
menu.addAction("打开文件")
menu.addAction("保存")
menu.addSeparator()
menu.addAction("退出")

# 显示菜单
menu.exec(QCursor.pos())
```

### 作为下拉按钮的菜单

```python
from PyQtWidgetForge.common.elements.menu import RoundMenu
from PyQtWidgetForge.widgets.button import DropdownButton

# 创建下拉按钮
dropdown_btn = DropdownButton("下拉菜单")

# 创建并设置菜单
menu = RoundMenu()
menu.addAction("菜单项1")
menu.addAction("菜单项2")
dropdown_btn.setMenu(menu)
```

### 作为右键菜单

```python
from PyQt6.QtCore import Qt
from PyQtWidgetForge.common.elements.menu import RoundMenu

# 在widget上设置右键菜单策略
widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
widget.customContextMenuRequested.connect(self.show_context_menu)

def show_context_menu(self, position):
    menu = RoundMenu()
    menu.addAction("复制")
    menu.addAction("粘贴")
    menu.exec(widget.mapToGlobal(position))
```

### 创建多级子菜单

```python
from PyQtWidgetForge.common.elements.menu import RoundMenu

# 创建主菜单
menu = RoundMenu()
menu.addAction("新建文件")
menu.addAction("打开文件")

# 创建一级子菜单
file_menu = menu.addMenu("最近文件")
file_menu.addAction("文档1.txt")
file_menu.addAction("项目报告.docx")

# 创建二级子菜单
edit_menu = menu.addMenu("编辑选项")
edit_menu.addAction("复制")
edit_menu.addAction("粘贴")

# 创建三级子菜单
format_menu = edit_menu.addMenu("格式化选项")
format_menu.addAction("自动格式化")
format_menu.addAction("缩进")
```

### 自定义圆角半径

```python
from PyQtWidgetForge.common.elements.menu import RoundMenu

# 创建具有15像素圆角的菜单
menu = RoundMenu(radius=15)
```

### 自定义颜色

```python
from PyQtWidgetForge.common.elements.menu import RoundMenu

# 方法1: 创建菜单时直接指定背景色
menu = RoundMenu(bg_color="#f8f9fa")  # 浅色背景
# 或创建深色背景菜单
menu = RoundMenu(bg_color="#343a40")  # 深色背景

# 方法2: 创建后再设置背景色
menu = RoundMenu()  # 默认为白色背景
menu.set_colors(bg_color="#3498db")  # 蓝色背景

# 智能颜色系统会自动根据背景色调整以下颜色:
# - 文本颜色: 深色背景使用白色文本，浅色背景使用深色文本
# - 边框颜色: 根据文本颜色自动生成半透明边框
# - 高亮颜色: 深色背景下变亮，浅色背景下变暗
# - 分隔线颜色: 文本颜色的半透明版本
# - 禁用文本颜色: 文本颜色的半透明版本
```

### 自定义样式

```python
from PyQtWidgetForge.common.elements.menu import RoundMenu

# 创建菜单并自定义样式
menu = RoundMenu(radius=15)
menu.setStyleSheet("""
    QMenu {
        background-color: #34495e;
        border: 1px solid #2c3e50;
        border-radius: 15px;
        padding: 8px;
    }
    QMenu::item {
        background-color: transparent;
        padding: 8px 12px 8px 10px;
        border-radius: 10px;
        margin: 3px;
        color: white;
    }
    QMenu::item:selected {
        background-color: #3498db;
    }
    QMenu::separator {
        height: 1px;
        background-color: #7f8c8d;
        margin: 5px 5px;
    }
""")
```

### 使用菜单位置选择功能

```python
from PyQtWidgetForge.common.elements.menu import RoundMenu, PopupPosition, AlignPoint

# 创建菜单
menu = RoundMenu()
menu.addAction("菜单项1")
menu.addAction("菜单项2")

# 基本位置选择
button = QPushButton("按钮")

# 1. 在目标控件底部显示菜单，菜单顶部中心与按钮底部中心对齐
menu.exec(target_widget=button, pos_type=PopupPosition.BOTTOM, align_point=AlignPoint.TOP)

# 2. 在目标控件右侧显示菜单，菜单左侧中心与按钮右侧中心对齐
menu.exec(target_widget=button, pos_type=PopupPosition.RIGHT, align_point=AlignPoint.LEFT)

# 3. 在鼠标光标位置显示菜单，菜单中心与鼠标位置对齐
menu.exec(pos_type=PopupPosition.CURSOR, align_point=AlignPoint.CENTER)

# 4. 在鼠标光标位置显示菜单，菜单左上角与鼠标位置对齐（默认行为）
menu.exec(pos_type=PopupPosition.CURSOR)

# 5. 自动选择最佳位置显示菜单
menu.exec(target_widget=button, pos_type=PopupPosition.AUTO)
```

### 位置枚举说明

`PopupPosition` 枚举提供以下位置选项：

| 枚举值 | 描述 |
|-------|------|
| `AUTO` | 自动选择最佳位置（根据屏幕空间） |
| `CURSOR` | 在鼠标光标位置显示 |
| `CENTER` | 在目标控件中心位置 |
| `TOP_LEFT` | 控件的左上角 |
| `TOP` | 控件的顶部中心 |
| `TOP_RIGHT` | 控件的右上角 |
| `RIGHT` | 控件的右侧中心 |
| `BOTTOM_RIGHT` | 控件的右下角 |
| `BOTTOM` | 控件的底部中心 |
| `BOTTOM_LEFT` | 控件的左下角 |
| `LEFT` | 控件的左侧中心 |

### 对齐点枚举说明

`AlignPoint` 枚举定义了菜单的哪个点应该与目标位置对齐：

| 枚举值 | 描述 |
|-------|------|
| `TOP_LEFT` | 菜单的左上角（默认值） |
| `TOP` | 菜单的顶部中心 |
| `TOP_RIGHT` | 菜单的右上角 |
| `RIGHT` | 菜单的右侧中心 |
| `BOTTOM_RIGHT` | 菜单的右下角 |
| `BOTTOM` | 菜单的底部中心 |
| `BOTTOM_LEFT` | 菜单的左下角 |
| `LEFT` | 菜单的左侧中心 |
| `CENTER` | 菜单的中心 |

通过组合不同的位置和对齐点，可以实现非常精确的菜单定位。例如：

```python
# 将菜单的右侧中心与按钮的左侧中心对齐（菜单在按钮左侧）
menu.exec(target_widget=button, pos_type=PopupPosition.LEFT, align_point=AlignPoint.RIGHT)

# 将菜单的左上角与按钮的右下角对齐
menu.exec(target_widget=button, pos_type=PopupPosition.BOTTOM_RIGHT, align_point=AlignPoint.TOP_LEFT)

# 将菜单的底部中心与按钮的顶部中心对齐（菜单在按钮上方）
menu.exec(target_widget=button, pos_type=PopupPosition.TOP, align_point=AlignPoint.BOTTOM)
```

## API参考

### 构造函数

```python
RoundMenu(title=None, parent=None, radius=8, bg_color="#ffffff")
```

- `title` (str, 可选): 菜单标题
- `parent` (QWidget, 可选): 父级组件
- `radius` (int): 圆角半径，默认为8像素
- `bg_color` (str): 背景颜色，默认为白色。其他颜色会根据背景色自动计算

### 方法

| 方法 | 描述 |
|------|------|
| `set_radius(radius)` | 设置圆角半径 |
| `get_radius()` | 获取当前圆角半径 |
| `set_border_width(width)` | 设置边框宽度 |
| `get_border_width()` | 获取当前边框宽度 |
| `set_colors(bg_color)` | 设置背景颜色，其他颜色会自动调整 |
| `get_colors()` | 获取当前菜单所有颜色的字典 |
| `addAction(text, slot=None)` | 添加菜单项及其槽函数 |
| `addSeparator()` | 添加分隔线 |
| `addMenu(menu_or_title)` | 添加子菜单，可以传入菜单对象或标题字符串 |
| `exec(position=None, target_widget=None, pos_type=PopupPosition.AUTO, align_point=AlignPoint.TOP_LEFT)` | 在指定位置显示菜单并返回选中的动作 |
| `popup(position, action=None, target_widget=None, pos_type=PopupPosition.AUTO, align_point=AlignPoint.TOP_LEFT)` | 在指定位置弹出菜单 |

### 继承的方法

RoundMenu继承自PyQt6的QMenu，因此可以使用QMenu的所有方法，例如：

- `clear()`: 清除所有菜单项
- `isEmpty()`: 检查菜单是否为空
- `setTitle(title)`: 设置菜单标题
- `setIcon(icon)`: 设置菜单图标

## 注意事项

1. 使用下拉按钮时，建议使用RoundMenu，以保持统一的视觉风格。
2. 自定义样式时，请确保border-radius与创建时指定的radius或通过set_radius设置的值保持一致。
3. 子菜单会自动继承父菜单的颜色设置，不需要单独设置。
4. 菜单显示时会有淡入动画效果，无需额外配置。
5. 菜单会自动调整位置，确保不会超出屏幕边界。
6. 只需设置背景色，其他颜色会自动计算，确保最佳的对比度和易读性：
   - 深色背景会自动使用浅色文本和相应的边框/高亮颜色
   - 浅色背景会自动使用深色文本和相应的边框/高亮颜色 