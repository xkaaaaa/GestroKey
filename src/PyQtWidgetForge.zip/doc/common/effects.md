# 特效模块

`PyQtWidgetForge.common.effects` 模块提供了可用于各种组件的视觉特效。这些特效可以增强用户界面的视觉反馈，提高用户交互体验。

## 阴影效果

阴影效果为控件提供可以通过动画方式改变的阴影效果，可用于按钮、卡片等需要立体感的组件。

### AnimatedShadowEffect

`AnimatedShadowEffect` 类为控件提供可动画化的阴影效果，支持不同状态间的平滑过渡。

#### 基本用法

```python
from PyQtWidgetForge.common.effects import AnimatedShadowEffect

# 创建阴影效果并应用到按钮
shadow_effect = AnimatedShadowEffect(my_button)

# 在鼠标悬停时改变阴影状态
shadow_effect.set_state("hover")

# 在鼠标按下时改变阴影状态
shadow_effect.set_state("pressed")

# 在控件禁用时改变阴影状态
shadow_effect.set_state("disabled")
```

#### 自定义阴影状态

```python
from PyQt6.QtGui import QColor

# 定义自定义状态
shadow_effect.set_custom_state(
    "highlighted",  # 状态名称
    4.0,            # 阴影偏移
    10.0,           # 阴影模糊半径
    QColor(0, 100, 200, 80)  # 阴影颜色
)

# 应用自定义状态
shadow_effect.set_state("highlighted")
```

#### 设置动画时间

```python
# 设置动画持续时间（毫秒）
shadow_effect.set_animation_duration(300)
```

#### 常用方法

| 方法 | 描述 |
| --- | --- |
| `set_state(state_name, animate=True)` | 设置阴影状态，状态名可以是预定义的或自定义的 |
| `set_custom_state(state_name, offset, blur_radius, color)` | 定义自定义阴影状态 |
| `set_animation_duration(duration)` | 设置状态变化动画持续时间（毫秒） |
| `get_current_state()` | 获取当前状态名称 |
| `stop_animations()` | 停止所有正在进行的动画 |

## 辉光效果

辉光效果为控件提供可以通过动画方式改变的发光效果，可用于强调重要控件或提供视觉反馈。

### AnimatedGlowEffect

`AnimatedGlowEffect` 类为控件提供可动画化的四周发光效果，支持不同状态间的平滑过渡。

#### 基本用法

```python
from PyQtWidgetForge.common.effects import AnimatedGlowEffect
from PyQt6.QtGui import QColor

# 创建辉光效果并应用到按钮，设置蓝色辉光
glow_effect = AnimatedGlowEffect(my_button, glow_color=QColor(61, 174, 233))

# 在鼠标悬停时增强辉光效果
glow_effect.set_state("hover")

# 在鼠标按下时进一步增强辉光效果
glow_effect.set_state("pressed")

# 在控件禁用时减弱辉光效果
glow_effect.set_state("disabled")
```

#### 自定义辉光状态

```python
# 定义自定义状态
glow_effect.set_custom_state(
    "highlighted",  # 状态名称
    0.8,            # 辉光强度 (0.0-1.0)
    20.0            # 辉光模糊半径
)

# 应用自定义状态
glow_effect.set_state("highlighted")
```

#### 改变辉光颜色

```python
from PyQt6.QtGui import QColor

# 设置辉光颜色为绿色
glow_effect.set_glow_color(QColor(46, 204, 113))

# 设置辉光颜色为红色
glow_effect.set_glow_color(QColor(231, 76, 60))
```

#### 设置动画时间

```python
# 设置动画持续时间（毫秒）
glow_effect.set_animation_duration(300)
```

#### 常用方法

| 方法 | 描述 |
| --- | --- |
| `set_state(state_name, animate=True)` | 设置辉光状态，状态名可以是预定义的或自定义的 |
| `set_custom_state(state_name, strength, blur_radius)` | 定义自定义辉光状态 |
| `set_glow_color(color)` | 设置辉光颜色 |
| `get_glow_color()` | 获取当前辉光颜色 |
| `set_animation_duration(duration)` | 设置状态变化动画持续时间（毫秒） |
| `get_current_state()` | 获取当前状态名称 |
| `stop_animations()` | 停止所有正在进行的动画 |

## 预定义状态

两种效果都预定义了以下状态：

| 状态名 | 描述 |
| --- | --- |
| `normal` | 正常状态，默认显示效果 |
| `hover` | 鼠标悬停状态，增强效果 |
| `pressed` | 按下状态，最强效果 |
| `disabled` | 禁用状态，减弱效果 | 