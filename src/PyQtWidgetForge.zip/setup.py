import os
import sys
from setuptools import setup, find_packages

# 添加当前目录到系统路径
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

# 从version模块获取版本信息
from PyQtWidgetForge.version import (
    VERSION, 
    APP_NAME, 
    APP_DESCRIPTION, 
    AUTHOR, 
    LICENSE,
    REPO_URL
)

# 读取README文件
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# 设置依赖
required_packages = [
    "PyQt6>=6.0.0"
]

setup(
    name=APP_NAME,
    version=VERSION,
    author=AUTHOR,
    author_email=f"{AUTHOR.lower()}@example.com",  # 替换为真实邮箱
    description=APP_DESCRIPTION,
    long_description=long_description,
    long_description_content_type="text/markdown",
    url=REPO_URL,
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=required_packages,
    keywords="pyqt6, qt, widgets, components, ui",
)