"""
PyQtWidgetForge - PyQt6组件库

提供一系列可重用的PyQt6自定义组件
"""

from .version import APP_NAME, VERSION, get_full_version_info, get_version_string

# 导出版本信息
__version__ = VERSION
__app_name__ = APP_NAME

# 导出公共API
__all__ = [
    "VERSION",
    "APP_NAME",
    "get_version_string",
    "get_full_version_info",
    "widgets",
    "styles",
    "utils",
    "common",
    "Button",
    "ForgeButton",
    "Window",
    "ThemeMode",
    "SmoothTransition",
    "AnimatedShadowEffect",
    "AnimatedGlowEffect",
]

# 导入子包 - 避免循环导入问题
from . import widgets

# 样式模块可能尚未完全实现，使用try-except避免导入错误
try:
    from . import styles
except ImportError:
    # 如果styles模块不存在或有问题，创建一个空对象
    import sys
    import types

    styles = types.ModuleType("styles")
    sys.modules["PyQtWidgetForge.styles"] = styles

from . import common, utils

# 从common导入常用动画和特效
from .common.animations import SmoothTransition
from .common.effects import AnimatedGlowEffect, AnimatedShadowEffect

# 从widgets导入常用组件，方便直接使用
from .widgets import Button, ForgeButton, ThemeMode, Window
