"""
图标工具模块

提供加载和处理SVG图标的功能
"""
import os
from pathlib import Path

from PyQt6.QtCore import QSize, Qt
from PyQt6.QtGui import QColor, QIcon, QPainter, QPixmap
from PyQt6.QtSvg import QSvgRenderer


class IconManager:
    """
    图标管理器

    用于加载和管理SVG图标资源
    """

    def __init__(self):
        """初始化图标管理器"""
        # 获取图标目录路径
        self._icons_root = self._get_icons_root()

        # 图标缓存
        self._icon_cache = {}

        # 图标目录列表（按优先级排序，先找到的图标优先使用）
        self._icon_dirs = [
            self._icons_root / "svg",  # Feather图标集
            self._icons_root / "bootstrap",  # Bootstrap图标集
        ]

        # 初始化图标名称到文件路径的映射
        self._icon_paths = {}
        self._load_icons()

    def _get_icons_root(self):
        """获取图标根目录路径"""
        # 获取当前文件所在的目录
        current_file = Path(__file__).resolve()
        # 获取项目根目录 - 使用相对路径
        module_dir = current_file.parent.parent  # PyQtWidgetForge目录
        # 构建图标目录路径
        icons_root = module_dir / "resources" / "icons"

        # 检查目录是否存在
        if not icons_root.exists():
            raise FileNotFoundError(f"图标目录不存在: {icons_root}")

        return icons_root

    def _load_icons(self):
        """加载所有图标集的图标路径到内存映射"""
        for icon_dir in self._icon_dirs:
            if not icon_dir.exists():
                continue

            # 遍历目录中的所有SVG文件
            for file_path in icon_dir.glob("*.svg"):
                icon_name = file_path.stem

                # 如果图标名称已存在，跳过（保持优先级顺序）
                if icon_name not in self._icon_paths:
                    self._icon_paths[icon_name] = file_path

    def get_icon(self, name, color=None, size=None):
        """
        获取指定名称的图标

        参数:
            name (str): 图标名称，不包含扩展名
            color (str): 图标颜色，例如 '#FF0000'，默认为None（使用原始颜色）
            size (QSize): 图标大小，默认为None（使用原始大小）

        返回:
            QIcon: 加载的图标对象
        """
        # 构建缓存键
        cache_key = f"{name}_{color}_{size}"

        # 检查缓存
        if cache_key in self._icon_cache:
            return self._icon_cache[cache_key]

        # 检查图标是否存在
        if name not in self._icon_paths:
            print(f"警告: 图标不存在 - {name}")
            return QIcon()

        # 获取图标文件路径
        icon_path = self._icon_paths[name]

        # 加载SVG图标
        icon = self._load_svg_icon(icon_path, color, size)

        # 添加到缓存
        self._icon_cache[cache_key] = icon

        return icon

    def _load_svg_icon(self, icon_path, color=None, size=None):
        """
        加载SVG图标

        参数:
            icon_path (Path): 图标文件路径
            color (str): 图标颜色
            size (QSize): 图标大小

        返回:
            QIcon: 加载的图标对象
        """
        # 创建图标对象
        icon = QIcon()

        # 如果没有指定颜色和大小，直接加载原始图标
        if not color and not size:
            icon.addFile(str(icon_path))
            return icon

        # 读取SVG内容
        with open(icon_path, "r") as f:
            svg_content = f.read()

        # 如果指定了颜色，替换颜色
        if color:
            # 简单替换，假设SVG中使用了stroke或fill属性
            svg_content = svg_content.replace(
                'stroke="currentColor"', f'stroke="{color}"'
            )
            svg_content = svg_content.replace('fill="currentColor"', f'fill="{color}"')

        # 使用QSvgRenderer渲染图标
        renderer = QSvgRenderer(bytes(svg_content, "utf-8"))

        # 如果没有指定大小，使用SVG的默认大小
        if not size:
            size = renderer.defaultSize()

        # 创建QPixmap并渲染SVG
        pixmap = QPixmap(size)
        pixmap.fill(Qt.GlobalColor.transparent)  # 设置透明背景

        # 渲染SVG到QPixmap
        painter = None
        try:
            painter = QPainter(pixmap)
            if painter.isActive():  # 确保绘制引擎有效
                renderer.render(painter)
        except Exception as e:
            print(f"SVG渲染错误: {str(e)}")
        finally:
            if painter and painter.isActive():
                painter.end()  # 确保painter总是被正确终止

        # 添加到图标
        icon.addPixmap(pixmap)

        return icon

    def list_available_icons(self):
        """
        列出所有可用的图标名称

        返回:
            list: 图标名称列表
        """
        return sorted(list(self._icon_paths.keys()))


# 创建全局图标管理器实例
icon_manager = IconManager()


# 导出便捷函数
def get_icon(name, color=None, size=None):
    """
    获取指定名称的图标

    参数:
        name (str): 图标名称，不包含扩展名
        color (str): 图标颜色，例如 '#FF0000'，默认为None（使用原始颜色）
        size (QSize): 图标大小，默认为None（使用原始大小）

    返回:
        QIcon: 加载的图标对象
    """
    return icon_manager.get_icon(name, color, size)


def list_icons():
    """
    列出所有可用的图标名称

    返回:
        list: 图标名称列表
    """
    return icon_manager.list_available_icons()
