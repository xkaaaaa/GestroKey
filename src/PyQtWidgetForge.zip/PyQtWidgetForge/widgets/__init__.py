"""
UI组件模块

提供 ForgeButton 及窗口相关组件的快捷导出
"""

from .button import ForgeButton  # noqa: F401
from .window import ThemeManager, ThemeMode, Window

# 兼容旧名称
Button = ForgeButton
NormalButton = ForgeButton

__all__ = [
    "ForgeButton",
    "Button",
    "NormalButton",
    "Window",
    "ThemeMode",
    "ThemeManager",
]
