"""
主窗口组件模块

提供支持主题切换的主窗口组件
"""
from PyQt6.QtCore import QEvent, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QPalette
from PyQt6.QtWidgets import QApplication, QMainWindow, QStyleFactory

from .theme import ThemeManager, ThemeMode


class Window(QMainWindow):
    """
    主窗口组件

    继承自QMainWindow，提供主题切换和样式管理功能。
    使用方法与原生QMainWindow相同，但自动支持主题跟随。
    """

    # 定义信号
    theme_changed = pyqtSignal(bool)  # 主题变更信号，参数为是否为深色模式

    def __init__(
        self,
        parent=None,
        title="PyQtWidgetForge Window",
        width=800,
        height=600,
        theme_mode=None,
        theme_color=None,
    ):
        """
        初始化主窗口

        参数:
            parent: 父组件
            title (str): 窗口标题
            width (int): 窗口宽度
            height (int): 窗口高度
            theme_mode (ThemeMode): 主题模式，None表示使用全局设置
            theme_color (QColor): 主题颜色，None表示使用全局设置
        """
        super().__init__(parent)

        # 设置窗口属性
        self.setWindowTitle(title)
        self.resize(width, height)

        # 获取主题管理器
        self._theme_manager = ThemeManager.instance()

        # 如果指定了主题模式和颜色，应用到全局设置
        if theme_mode is not None:
            self._theme_manager.set_theme_mode(theme_mode)

        if theme_color is not None:
            self._theme_manager.set_theme_color(theme_color)

        # 应用主题
        self._apply_theme()

        # 连接主题变更信号
        self._theme_manager.theme_changed.connect(self._on_theme_changed)

        # 安装事件过滤器，用于检测应用程序的调色板变化
        app = QApplication.instance()
        if app:
            app.installEventFilter(self)

    def eventFilter(self, obj, event):
        """事件过滤器，用于捕获调色板变化事件"""
        if event.type() == QEvent.Type.ApplicationPaletteChange:
            # 系统主题可能发生变化，刷新主题设置
            self._theme_manager.refresh()
        return super().eventFilter(obj, event)

    def _on_theme_changed(self):
        """主题变更处理函数"""
        self._apply_theme()
        # 发出自定义信号，参数为是否为深色模式
        self.theme_changed.emit(self._theme_manager.is_dark_mode())

    def _apply_theme(self):
        """应用当前主题设置"""
        app = QApplication.instance()
        if not app:
            return

        # 根据主题模式设置应用程序样式
        is_dark = self._theme_manager.is_dark_mode()

        # 保存当前样式
        current_style = app.style().objectName()

        # 如果当前样式不是Fusion，才设置基础样式，避免重复创建样式对象导致崩溃
        if current_style.lower() != "fusion":
            app.setStyle(QStyleFactory.create("Fusion"))

        # 根据主题模式设置调色板
        palette = QPalette()
        if is_dark:
            # 深色主题调色板
            palette.setColor(QPalette.ColorRole.Window, QColor(53, 53, 53))
            palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
            palette.setColor(QPalette.ColorRole.Base, QColor(35, 35, 35))
            palette.setColor(QPalette.ColorRole.AlternateBase, QColor(53, 53, 53))
            palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(25, 25, 25))
            palette.setColor(QPalette.ColorRole.ToolTipText, Qt.GlobalColor.white)
            palette.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.white)
            palette.setColor(QPalette.ColorRole.Button, QColor(53, 53, 53))
            palette.setColor(QPalette.ColorRole.ButtonText, Qt.GlobalColor.white)
            palette.setColor(QPalette.ColorRole.BrightText, Qt.GlobalColor.red)
            palette.setColor(QPalette.ColorRole.Link, QColor(42, 130, 218))
            palette.setColor(
                QPalette.ColorRole.Highlight, self._theme_manager.get_theme_color()
            )
            palette.setColor(QPalette.ColorRole.HighlightedText, Qt.GlobalColor.black)
        else:
            # 浅色主题调色板
            palette.setColor(QPalette.ColorRole.Window, QColor(240, 240, 240))
            palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.black)
            palette.setColor(QPalette.ColorRole.Base, Qt.GlobalColor.white)
            palette.setColor(QPalette.ColorRole.AlternateBase, QColor(233, 233, 233))
            palette.setColor(QPalette.ColorRole.ToolTipBase, Qt.GlobalColor.white)
            palette.setColor(QPalette.ColorRole.ToolTipText, Qt.GlobalColor.black)
            palette.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.black)
            palette.setColor(QPalette.ColorRole.Button, QColor(240, 240, 240))
            palette.setColor(QPalette.ColorRole.ButtonText, Qt.GlobalColor.black)
            palette.setColor(QPalette.ColorRole.BrightText, Qt.GlobalColor.red)
            palette.setColor(QPalette.ColorRole.Link, QColor(0, 0, 255))
            palette.setColor(
                QPalette.ColorRole.Highlight, self._theme_manager.get_theme_color()
            )
            palette.setColor(QPalette.ColorRole.HighlightedText, Qt.GlobalColor.white)

        # 禁用组件的调色板设置
        palette.setColor(
            QPalette.ColorGroup.Disabled,
            QPalette.ColorRole.WindowText,
            QColor(127, 127, 127),
        )
        palette.setColor(
            QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor(127, 127, 127)
        )
        palette.setColor(
            QPalette.ColorGroup.Disabled,
            QPalette.ColorRole.ButtonText,
            QColor(127, 127, 127),
        )

        # 应用调色板
        app.setPalette(palette)

    def get_theme_mode(self):
        """获取当前主题模式"""
        return self._theme_manager.get_theme_mode()

    def set_theme_mode(self, mode):
        """
        设置主题模式

        参数:
            mode (ThemeMode): 主题模式
        """
        self._theme_manager.set_theme_mode(mode)

    def get_theme_color(self):
        """获取当前主题颜色"""
        return self._theme_manager.get_theme_color()

    def set_theme_color(self, color):
        """
        设置主题颜色

        参数:
            color (QColor): 主题颜色
        """
        self._theme_manager.set_theme_color(color)

    def is_dark_mode(self):
        """
        当前是否为深色模式

        返回:
            bool: 是否为深色模式
        """
        return self._theme_manager.is_dark_mode()
