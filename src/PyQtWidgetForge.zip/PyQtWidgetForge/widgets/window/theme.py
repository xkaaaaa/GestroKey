"""
主题管理模块

提供全局主题设置和管理，支持自动（跟随系统）、深色和浅色主题
"""
from enum import Enum

from PyQt6.QtCore import QObject, QSettings, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QPalette
from PyQt6.QtWidgets import QApplication


class ThemeMode(Enum):
    """主题模式枚举类"""

    AUTO = 0  # 自动（跟随系统）
    LIGHT = 1  # 浅色主题
    DARK = 2  # 深色主题

    @classmethod
    def from_string(cls, value):
        """从字符串转换为枚举值"""
        value = value.lower()
        if value == "auto":
            return cls.AUTO
        elif value == "light":
            return cls.LIGHT
        elif value == "dark":
            return cls.DARK
        return cls.AUTO

    def to_string(self):
        """转换为字符串表示"""
        if self == ThemeMode.AUTO:
            return "auto"
        elif self == ThemeMode.LIGHT:
            return "light"
        elif self == ThemeMode.DARK:
            return "dark"
        return "auto"


class ThemeManager(QObject):
    """
    主题管理器

    管理全局主题设置，包括主题模式（自动/深色/浅色）和主题颜色
    """

    # 定义信号
    theme_changed = pyqtSignal()  # 主题变更信号

    # 单例实例
    _instance = None

    # 默认主题颜色
    DEFAULT_THEME_COLOR = QColor(61, 174, 233)  # 默认蓝色

    @classmethod
    def instance(cls):
        """获取单例实例"""
        if cls._instance is None:
            cls._instance = ThemeManager()
        return cls._instance

    def __init__(self):
        """初始化主题管理器"""
        super().__init__()

        # 检查是否已存在实例
        if ThemeManager._instance is not None:
            raise RuntimeError("ThemeManager是单例类，请使用ThemeManager.instance()获取实例")

        # 初始化设置
        self._settings = QSettings("PyQtWidgetForge", "ThemeSettings")

        # 从设置中加载主题模式
        theme_str = self._settings.value("theme/mode", ThemeMode.AUTO.to_string())
        self._theme_mode = ThemeMode.from_string(theme_str)

        # 从设置中加载主题颜色
        color_str = self._settings.value("theme/color", self.DEFAULT_THEME_COLOR.name())
        self._theme_color = QColor(color_str)

        # 缓存当前是否为深色模式
        self._is_dark_mode = self._determine_is_dark_mode()

    def _determine_is_dark_mode(self):
        """确定当前是否应该使用深色模式"""
        if self._theme_mode == ThemeMode.DARK:
            return True
        elif self._theme_mode == ThemeMode.LIGHT:
            return False
        else:  # AUTO模式
            # 尝试检测系统主题
            app = QApplication.instance()
            if app:
                palette = app.palette()
                # 如果窗口背景色较暗，则认为是深色模式
                window_color = palette.color(QPalette.ColorRole.Window)
                brightness = (
                    window_color.red() * 299
                    + window_color.green() * 587
                    + window_color.blue() * 114
                ) / 1000
                return brightness < 128
            return False  # 默认为浅色模式

    def get_theme_mode(self):
        """获取当前主题模式"""
        return self._theme_mode

    def set_theme_mode(self, mode):
        """
        设置主题模式

        参数:
            mode (ThemeMode): 主题模式
        """
        if not isinstance(mode, ThemeMode):
            raise TypeError("mode必须是ThemeMode类型")

        if self._theme_mode != mode:
            self._theme_mode = mode
            self._settings.setValue("theme/mode", mode.to_string())

            # 更新深色模式缓存
            previous_is_dark = self._is_dark_mode
            self._is_dark_mode = self._determine_is_dark_mode()

            # 如果深色模式状态变化，发出信号
            if previous_is_dark != self._is_dark_mode or mode == ThemeMode.AUTO:
                self.theme_changed.emit()

    def get_theme_color(self):
        """获取当前主题颜色"""
        return self._theme_color

    def set_theme_color(self, color):
        """
        设置主题颜色

        参数:
            color (QColor): 主题颜色
        """
        if not isinstance(color, QColor):
            raise TypeError("color必须是QColor类型")

        if self._theme_color != color:
            self._theme_color = color
            self._settings.setValue("theme/color", color.name())
            self.theme_changed.emit()

    def is_dark_mode(self):
        """
        当前是否为深色模式

        返回:
            bool: 是否为深色模式
        """
        return self._is_dark_mode

    def refresh(self):
        """
        刷新主题设置

        在系统主题变更时调用，更新AUTO模式下的主题
        """
        previous_is_dark = self._is_dark_mode
        self._is_dark_mode = self._determine_is_dark_mode()

        # 如果深色模式状态变化，发出信号
        if (
            previous_is_dark != self._is_dark_mode
            and self._theme_mode == ThemeMode.AUTO
        ):
            self.theme_changed.emit()

    def get_themed_color(self, light_color, dark_color=None):
        """
        根据当前主题获取颜色

        参数:
            light_color (QColor): 浅色主题下的颜色
            dark_color (QColor): 深色主题下的颜色，如果为None则自动生成

        返回:
            QColor: 适合当前主题的颜色
        """
        if self._is_dark_mode:
            if dark_color is not None:
                return dark_color
            else:
                # 如果未指定深色主题颜色，尝试从浅色主题颜色生成
                h, s, l, a = light_color.getHslF()
                # 反转亮度
                l = 1.0 - l
                result = QColor()
                result.setHslF(h, s, l, a)
                return result
        else:
            return light_color
