"""按钮通用 Mixin 集合（独立于旧 button_old）。"""

from PyQt6.QtGui import QColor, QIcon

from ...utils import get_icon

__all__ = [
    "IconMixin",
    "ColorMixin",
]


class IconMixin:
    """统一图标支持功能。"""

    def __init__(self, icon_name: str | None = None):
        self._icon_name: str | None = icon_name

    # ------------------------------------------------------------------
    def set_icon_name(self, icon_name: str | None, color: str | None = None):
        """设置或更新图标。"""
        self._icon_name = icon_name
        if not icon_name:
            self.setIcon(QIcon())  # type: ignore[attr-defined]
            return

        # 解析颜色
        if color is None and hasattr(self, "get_text_icon_color"):
            color = self.get_text_icon_color().name()  # type: ignore[attr-defined]
        if color is None:
            color = "#000000"
        self.setIcon(get_icon(icon_name, color=color))  # type: ignore[attr-defined]

    # 内部工具
    def _update_icon_color(self):
        icon_name = getattr(self, "_icon_name", None)
        if icon_name and hasattr(self, "get_text_icon_color"):
            self.setIcon(get_icon(icon_name, color=self.get_text_icon_color().name()))  # type: ignore[attr-defined]

    # 兼容旧名
    update_icon_color = _update_icon_color


class ColorMixin:
    """颜色与文字对比度计算、动画辅助。"""

    @staticmethod
    def _calculate_best_text_color(background_color: QColor) -> QColor:
        r, g, b = (
            background_color.red(),
            background_color.green(),
            background_color.blue(),
        )
        brightness = (r * 299 + g * 587 + b * 114) / 1000
        return QColor(0, 0, 0) if brightness >= 128 else QColor(255, 255, 255)

    # 动画封装由按钮基类实现，此处只提供文字颜色重计算
    def recalculate_text_color(self):  # noqa: D401
        """重新计算文本/图标颜色。"""
        if not hasattr(self, "_current_color"):
            return
        self._text_icon_color = self._calculate_best_text_color(self._current_color)  # type: ignore[attr-defined]
        if hasattr(self, "_update_icon_color"):
            self._update_icon_color()  # type: ignore[attr-defined]
        self.update()  # type: ignore[attr-defined] 

from PyQt6.QtGui import QColor, QIcon

from ...utils import get_icon

__all__ = [
    "IconMixin",
    "ColorMixin",
]


class IconMixin:
    """统一图标支持功能。"""

    def __init__(self, icon_name: str | None = None):
        self._icon_name: str | None = icon_name

    # ------------------------------------------------------------------
    def set_icon_name(self, icon_name: str | None, color: str | None = None):
        """设置或更新图标。"""
        self._icon_name = icon_name
        if not icon_name:
            self.setIcon(QIcon())  # type: ignore[attr-defined]
            return

        # 解析颜色
        if color is None and hasattr(self, "get_text_icon_color"):
            color = self.get_text_icon_color().name()  # type: ignore[attr-defined]
        if color is None:
            color = "#000000"
        self.setIcon(get_icon(icon_name, color=color))  # type: ignore[attr-defined]

    # 内部工具
    def _update_icon_color(self):
        icon_name = getattr(self, "_icon_name", None)
        if icon_name and hasattr(self, "get_text_icon_color"):
            self.setIcon(get_icon(icon_name, color=self.get_text_icon_color().name()))  # type: ignore[attr-defined]

    # 兼容旧名
    update_icon_color = _update_icon_color


class ColorMixin:
    """颜色与文字对比度计算、动画辅助。"""

    @staticmethod
    def _calculate_best_text_color(background_color: QColor) -> QColor:
        r, g, b = (
            background_color.red(),
            background_color.green(),
            background_color.blue(),
        )
        brightness = (r * 299 + g * 587 + b * 114) / 1000
        return QColor(0, 0, 0) if brightness >= 128 else QColor(255, 255, 255)

    # 动画封装由按钮基类实现，此处只提供文字颜色重计算
    def recalculate_text_color(self):  # noqa: D401
        """重新计算文本/图标颜色。"""
        if not hasattr(self, "_current_color"):
            return
        self._text_icon_color = self._calculate_best_text_color(self._current_color)  # type: ignore[attr-defined]
        if hasattr(self, "_update_icon_color"):
            self._update_icon_color()  # type: ignore[attr-defined]
        self.update()  # type: ignore[attr-defined] 
 
 
 