from __future__ import annotations

"""
新版按钮组件（普通按钮实现）

此文件提供 `Button` 类，初始实现等价于旧版本的 `NormalButton`，
后续会通过可选参数扩展为其他按钮类型。
"""

from typing import Optional

from PyQt6.QtWidgets import QWidget, QPushButton
from PyQt6.QtCore import QSize, QPointF, QEasingCurve, pyqtProperty, Qt, QPoint, QRectF, QRect
from PyQt6.QtGui import QColor, QPainter, QPainterPath, QBrush

# 按钮基类和工具
from .base import AnimatedButton
from .mixins import IconMixin
from ..window.theme import ThemeManager
from ...utils import get_icon

# 占位阴影类，用于辉光按钮替换阴影对象，避免后续动画访问已删除的 QGraphicsDropShadowEffect


class _NullShadow:  # pylint: disable=too-few-public-methods
    """空阴影占位，提供 set_state 接口但不执行任何操作。"""

    def set_state(self, *args, **kwargs):
        pass


class ForgeButton(IconMixin, AnimatedButton):
    """通用按钮（当前实现为普通按钮）。"""

    # 信息按钮颜色映射
    INFO_COLORS = {
        "info": (QColor(61, 174, 233), QColor(41, 152, 211), QColor(31, 133, 192), "#1f72a2", "white"),
        "success": (QColor(46, 204, 113), QColor(39, 174, 96), QColor(33, 148, 83), "#206d46", "white"),
        "warning": (QColor(241, 196, 15), QColor(212, 172, 13), QColor(183, 149, 11), "#b3920b", "white"),
        "danger": (QColor(231, 76, 60), QColor(192, 57, 43), QColor(169, 50, 38), "#a32321", "white"),
        "default": (QColor(248, 248, 248), QColor(230, 230, 230), QColor(210, 210, 210), "#c0c0c0", "#333333"),
    }

    def __init__(
        self,
        text: str = "",
        parent: Optional[QWidget] = None,
        icon_name: Optional[str] = None,
        emphasized: bool = False,
        flat: bool = False,
        link: bool = False,
        level: str | None = None,
        rounded: bool = False,
        glow_color: str | None = None,
        button_type: str = "basic",  # 新增：按钮类型 basic / toggle / dropdown / split
    ) -> None:
        """创建按钮。

        参数:
            text: 按钮文本。
            parent: 父级组件。
            icon_name: 图标名称（来自内置图标库），为 ``None`` 表示无图标。
            emphasized: 是否为强调按钮。
            flat: 是否无边框（Flat 风格）。
            link: 是否链接按钮（文本风格，颜色使用主题色）。
            level: 信息级别（info/success/warning/danger/default），空表示普通按钮。
            rounded: 是否圆角按钮。
            glow_color: 辉光颜色(HEX)。为空则无辉光。
            button_type: 按钮类型：``basic`` / ``toggle`` / ``dropdown`` / ``split``。
        """
        # 初始化 AnimatedButton
        AnimatedButton.__init__(self, text, parent)
        # 初始化 IconMixin
        IconMixin.__init__(self, icon_name)

        # 标识强调状态
        self._emphasized: bool = emphasized
        self._flat: bool = flat
        self._link: bool = link
        self._level: str | None = (level if level else None)
        self._rounded: bool = rounded
        self._glow_color_str = glow_color
        self._glow_effect = None

        # ------------------ 按钮类型相关 ------------------
        self._button_type: str = button_type.lower() if button_type else "basic"
        # dropdown / split 专用
        self._menu = None  # type: ignore[assignment]
        self._arrow_shape = "triangle"  # 三角形 / 点
        # split 专用
        self._split_ratio = 0.75  # 左右按钮宽度比例，默认左侧占75%
        self._split_hover_part = None  # 当前悬停的部分：None, "left", "right"
        self._split_pressed_part = None  # 当前按下的部分：None, "left", "right"
        self._split_left_offset = QPointF(0, 0)  # 左侧内容偏移
        self._split_right_offset = QPointF(0, 0)  # 右侧内容偏移

        # toggle 专用
        self._checked_color = ThemeManager.instance().get_theme_color()

        # 是否跟随主题背景（普通按钮 True，强调按钮 False）
        self._follow_theme_background = not emphasized and not flat and (level is None)

        # 根据强调状态初始化颜色
        if emphasized and flat:
            raise ValueError("强调(emphasized) 和 无边框(flat) 不能同时启用")
        if link and (emphasized or flat):
            raise ValueError("链接按钮不可与强调或无边框同时启用")
        if level and (emphasized or link):
            raise ValueError("信息按钮不可与强调或链接同时启用")
        if rounded and (link or flat):
            raise ValueError("圆角按钮不可与链接或无边框同时启用")
        if glow_color and (flat or link):
            raise ValueError("辉光按钮不可与无边框或链接同时启用")
        if self._button_type == "toggle" and (emphasized or link or level):
            raise ValueError("选中(toggled) 按钮不可与强调、信息(level) 或 链接 同时启用")
        elif emphasized:
            self._apply_emphasis_colors()
        elif self._flat:
            self._apply_flat_defaults()
        elif self._level:
            self._apply_info_defaults(self._level)
        else:
            # AnimatedButton 在其 __init__ 已调用 _apply_theme_defaults
            pass

        # 根据按钮类型进行额外初始化
        if self._button_type == "toggle":
            self._init_toggle_button()
        elif self._button_type == "dropdown":
            self._init_dropdown_button()
        elif self._button_type == "split":
            self._init_split_button()

        # 生成并应用样式
        self._update_style()

        # 监听主题变化
        ThemeManager.instance().theme_changed.connect(self._on_theme_changed)

        # 若有图标，更新颜色
        if icon_name:
            self._update_icon_color()

    # ---------------------------------------------------------------------
    # 样式
    # ---------------------------------------------------------------------
    def _update_style(self) -> None:
        """根据当前主题或强调状态刷新边框样式。"""
        # dropdown / split 需要增加右侧内边距以容纳箭头
        dropdown_extra_padding = False
        if self._button_type == "dropdown" or self._button_type == "split":
            dropdown_extra_padding = True

        if self._link:
            self._apply_link_defaults()
            # _apply_link_defaults 现在会处理自己的样式表，包括禁用状态
            return

        if self._level:
            border_color = self._info_border_color
            disabled_border = border_color
        elif self._emphasized:
            border_color = self._normal_color.darker(140).name()
            disabled_border = self._normal_color.lighter(160).name()
        elif self._flat:
            border_color = "transparent"
            disabled_border = "transparent"
        elif self._glow_color_str:
            border_color = self._glow_color_str
            disabled_border = self._glow_color_str
        elif self._rounded:
            border_color = "#c0c0c0"
            disabled_border = "#d0d0d0"
        else:
            is_dark = ThemeManager.instance().is_dark_mode()
            border_color = "#4d4d4d" if is_dark else "#c0c0c0"
            disabled_border = "#5e5e5e" if is_dark else "#d0d0d0"

        # 计算 padding: 仅图标 -> 较窄
        if dropdown_extra_padding:
            # 右侧预留 28px 以绘制箭头
            if self.text():
                padding_rule = "padding: 6px 28px 6px 12px;"
            else:
                padding_rule = "padding: 6px 28px 6px 6px;"
        else:
            if self.text():
                padding_rule = "padding: 6px 12px;"
            else:
                padding_rule = "padding: 6px;"

        # 先确定禁用状态下的文本颜色
        tm = ThemeManager.instance()
        # 普通按钮的禁用文本颜色
        disabled_text_color_name = (QColor(120, 120, 120) if tm.is_dark_mode() else QColor(160, 160, 160)).name() # 恢复灰色
        
        # 获取当前启用的文本颜色，用于非禁用状态
        # 注意：_text_icon_color 可能在 setEnabled 或其他地方被修改
        # 对于普通状态，颜色由 paintEvent 使用 _text_icon_color 绘制，样式表通常不直接指定 color
        # 但为了保险起见，可以考虑也加入。
        current_text_color_name = self._text_icon_color.name()


        qss = f"""
            QPushButton {{
                border: 1px solid {border_color};
                border-radius: {16 if self._rounded else 4}px;
                {padding_rule}
                /* color: {current_text_color_name}; */ /* 普通状态颜色由绘制逻辑控制 */
            }}
            QPushButton:disabled {{
                border: 1px solid {disabled_border};
                color: {disabled_text_color_name};
            }}
        """
        # 对于 link 按钮，其样式表在 _apply_link_defaults 中单独设置，包含特殊颜色和下划线
        # 这里需要避免覆盖 link 按钮的特定样式，已在前面 return
        
        self.setStyleSheet(qss)

        # 若按钮当前为禁用，_text_icon_color 已在 setEnabled 设置，图标颜色也已更新
        # 此处的 if not self.isEnabled() 块主要是为了 paintEvent
        if not self.isEnabled():
            # _text_icon_color 已经由 setEnabled 设置为禁用颜色
            self._update_icon_color() # 确保图标颜色与文本颜色同步
            self.update() # 触发重绘
        else:
            # 对于启用状态，如果颜色是通过 self._text_icon_color 设置的（非样式表直接控制）
            # 确保图标颜色和重绘也被触发
            # self.recalculate_text_color() # 这个可能在 setEnabled 中处理更合适
            self._update_icon_color()
            self.update()


        # 若背景色已变，刷新前景色（flat/link/info 等已有自定义前景色时跳过）
        if self.isEnabled() and not (self._flat or self._link or self._level):
            self.recalculate_text_color()
            self._update_icon_color()

    # -----------------------------------------------------------------
    # 样式与主题辅助
    # -----------------------------------------------------------------
    def _apply_emphasis_colors(self):
        """根据 ThemeManager 主题色设置强调按钮配色"""
        theme_color = ThemeManager.instance().get_theme_color()
        self._normal_color = theme_color
        self._hover_color = theme_color.lighter(125)
        self._pressed_color = theme_color.darker(125)
        self._current_color = self._normal_color

    def _apply_flat_defaults(self):
        """无边框按钮默认前景色设置"""
        tm = ThemeManager.instance()
        # 背景完全透明
        self._normal_color = QColor(0, 0, 0, 0)
        self._hover_color = QColor(0, 0, 0, 0)
        self._pressed_color = QColor(0, 0, 0, 0)
        self._current_color = self._normal_color
        # 前景色：若为信息按钮，使用信息文字色；否则根据主题取黑/白
        if self._level and self._level in self.INFO_COLORS:
            n_color = self.INFO_COLORS[self._level][0]
            self._text_icon_color = n_color
        else:
            # 普通无边框按钮前景色：浅色主题使用深灰文字，深色主题使用白色文字
            if tm.is_dark_mode():
                self._text_icon_color = QColor("#ffffff")
            else:
                self._text_icon_color = QColor("#333333")
        # 记录 flat 基准颜色，以便 toggle 取消选中恢复
        self._flat_base_color = self._text_icon_color
        self._link_color = self._text_icon_color
        self._update_icon_color()
        self.update()

        # 预存颜色
        self._flat_default_color = self._text_icon_color
        # 悬停/聚焦颜色：
        #   • 信息按钮 -> 信息主色略深
        #   • 普通无边框按钮 -> 当前文本颜色略深(15%)
        if self._level and self._level in self.INFO_COLORS:
            self._flat_hover_color = self.INFO_COLORS[self._level][0].darker(115)
        else:
            # darker(115) 表示加深 15%
            self._flat_hover_color = self._text_icon_color.darker(115)

    def _apply_link_defaults(self):
        tm = ThemeManager.instance()
        theme_color = tm.get_theme_color()
        self._normal_color = QColor(0, 0, 0, 0)
        self._hover_color = QColor(0, 0, 0, 0)
        self._pressed_color = QColor(0, 0, 0, 0)
        self._current_color = self._normal_color

        link_normal_color = QColor("#3daee9") # 固定蓝色
        # 链接按钮禁用时的颜色
        disabled_link_color = QColor(160, 160, 160) if not tm.is_dark_mode() else QColor(120, 120, 120) # 恢复灰色

        # 如果当前是禁用状态，文本颜色应该是禁用色
        current_text_color = disabled_link_color if not self.isEnabled() else link_normal_color
        self._text_icon_color = current_text_color
        self._link_color = link_normal_color # _link_color 存储的是链接本身激活时的颜色
        self._update_icon_color()
        
        # 设置样式：链接颜色使用当前 _text_icon_color
        underline_rule = "text-decoration: underline;"
        # 悬停时颜色可以略微变化，例如加深或使用主题色
        link_hover_color = link_normal_color.name() # 默认与普通链接颜色相同，确保变量定义
        # link_hover_color = theme_color.name() # 或者 link_normal_color.lighter(110).name()

        self.setStyleSheet(
            f"""
            QPushButton {{
                color: {link_normal_color.name()};
                border: none;
                background-color: transparent;
                {underline_rule}
            }}
            QPushButton:hover {{
                /* color: {link_hover_color}; */ /* 可选：悬停时颜色变化 */
            }}
            QPushButton:disabled {{
                color: {disabled_link_color.name()}; /* 显式设置禁用颜色 */
                text-decoration: none; /* 禁用时通常无下划线 */
            }}
        """
        )
        self.update()

    def _apply_info_defaults(self, level: str):
        level = level if level in self.INFO_COLORS else "default"
        (n, h, p, border, txt_default) = self.INFO_COLORS[level]
        self._normal_color, self._hover_color, self._pressed_color = n, h, p
        self._current_color = self._normal_color
        self._info_border_color = border
        # 根据背景亮度自动决定前景色；fallback 使用映射默认
        self._text_icon_color = self._calculate_best_text_color(self._normal_color) or QColor(txt_default)
        self._update_icon_color()
        self.update()

    def _on_theme_changed(self):
        """主题变化回调，按强调状态更新配色"""
        if self._emphasized:
            self._apply_emphasis_colors()
        elif self._flat:
            self._apply_flat_defaults()
        elif self._link:
            self._apply_link_defaults()
        elif self._level:
            self._apply_info_defaults(self._level)
        else:
            self._apply_theme_defaults()

        # 重新计算前景色和图标（无边框按钮已在 _apply_flat_defaults 设置好前景色）
        if self.isEnabled() and hasattr(self, "recalculate_text_color") and not self._flat:
            self.recalculate_text_color()
        if hasattr(self, "_update_icon_color"):
            self._update_icon_color()
        self._update_style()

        # 若处于禁用状态，恢复为灰色
        if not self.isEnabled():
            tm = ThemeManager.instance() # 需要获取 ThemeManager 实例
            self._text_icon_color = QColor(160,160,160) if not tm.is_dark_mode() else QColor(120,120,120) # 恢复灰色
            self._update_icon_color()
            self.update()

    # -----------------------------------------------------------------
    # 辅助方法：确保禁用颜色
    # -----------------------------------------------------------------
    def _ensure_disabled_color_if_needed(self):
        """如果按钮当前被禁用，则强制设置禁用的文本和图标颜色。"""
        if not self.isEnabled():
            tm = ThemeManager.instance()
            self._text_icon_color = QColor(160, 160, 160) if not tm.is_dark_mode() else QColor(120, 120, 120)
            if hasattr(self, '_update_icon_color'): # 确保方法存在
                self._update_icon_color()

    # -----------------------------------------------------------------
    # 公共接口
    # -----------------------------------------------------------------
    def is_emphasized(self) -> bool:
        """返回是否为强调按钮"""
        return self._emphasized

    def set_emphasized(self, value: bool):
        """动态切换强调模式"""
        if self._button_type == "toggle" and value:
            raise ValueError("选中按钮不可与强调同时启用")
        if self._emphasized == value:
            return
        if value and self._flat:
            raise ValueError("无边框和强调不能同时启用")
        self._emphasized = value
        self._follow_theme_background = not value and not self._flat

        if value:
            self._apply_emphasis_colors()
        else:
            # 回到 flat / normal 默认
            if self._flat:
                self._apply_flat_defaults()
            else:
                self._apply_theme_defaults()

        self._ensure_disabled_color_if_needed()
        self._update_style()
        self.update()

    # IconMixin 已提供 _update_icon_color

    # -----------------------------------------------------------------
    # 文本与图标动态修改
    # -----------------------------------------------------------------
    def set_icon_name(self, icon_name: Optional[str], color: str | None = None):  # type: ignore[override]
        """重载 IconMixin 方法，添加样式刷新"""
        super().set_icon_name(icon_name, color)  # type: ignore[misc]
        self._update_style()

    def setText(self, text: str):  # type: ignore[override]
        """设置文本后刷新样式以匹配仅图标/文字按钮的 padding"""
        super().setText(text)
        self._update_style()

    # -----------------------------------------------------------------
    # 尺寸
    # -----------------------------------------------------------------
    def sizeHint(self):  # type: ignore[override]
        """如果仅图标则返回方形尺寸"""
        base = super().sizeHint()
        if not self.text():
            side = base.height()
            # 若下拉按钮，需要额外为箭头留宽度
            if self._button_type == "dropdown":
                return QSize(side + 22, side)  # 22≈箭头+左右 padding
            # 其他 icon-only 按钮保持方形
            return QSize(side, side)
        return base

    def is_flat(self):
        return self._flat

    def set_flat(self, value: bool):
        if self._flat == value:
            return
        if value and self._emphasized:
            raise ValueError("无边框和强调不能同时启用")
        self._flat = value
        self._follow_theme_background = not value and not self._emphasized
        if value:
            self._apply_flat_defaults()
        else:
            self._apply_theme_defaults()
        
        self._ensure_disabled_color_if_needed()
        self._update_style()
        self.update()

    def eventFilter(self, watched, event):
        # 首先处理辉光效果过渡
        if watched == self and self._glow_effect is not None and self.isEnabled():
            t = event.type()
            if t == event.Type.Enter:
                self._glow_effect.set_state("hover")
            elif t == event.Type.Leave:
                self._glow_effect.set_state("normal")
            elif t == event.Type.MouseButtonPress:
                self._glow_effect.set_state("pressed")
            elif t == event.Type.MouseButtonRelease:
                self._glow_effect.set_state("hover")
            # 鼠标释放时保持悬停颜色，可忽略动画

        # 先处理 flat 专用前景色变换
        if watched == self and self._flat and self.isEnabled():
            t = event.type()
            if t == event.Type.Enter:
                self._transition.color_change(
                    self,
                    b"textColor",
                    self._text_icon_color,
                    self._flat_hover_color,
                    200,
                    QEasingCurve.Type.OutCubic,
                )
            elif t == event.Type.Leave:
                self._transition.color_change(
                    self,
                    b"textColor",
                    self._text_icon_color,
                    self._flat_default_color,
                    200,
                    QEasingCurve.Type.OutCubic,
                )

        # 委托给基类处理其他动画等
        return super().eventFilter(watched, event)

    # -----------------------------------------------------------------
    # 文本颜色属性，用于动画
    # -----------------------------------------------------------------
    @pyqtProperty(QColor)
    def textColor(self):  # noqa: N802
        return self._text_icon_color

    @textColor.setter
    def textColor(self, color):  # noqa: N802
        if self._text_icon_color != color:
            self._text_icon_color = color
            self._update_icon_color()
            self.update()

    # -----------------------------------------------------------------
    # 启用 / 禁用 – 同步文字与图标颜色
    # -----------------------------------------------------------------
    def setEnabled(self, enabled: bool):  # type: ignore[override]
        super().setEnabled(enabled)

        tm = ThemeManager.instance()
        if enabled:
            # 恢复正常颜色 - 顺序很重要，确保特殊类型优先处理
            if self._link:
                self._apply_link_defaults() # 链接按钮有自己的颜色和样式表逻辑
            elif self._emphasized:
                self._apply_emphasis_colors()
                self.recalculate_text_color()
            elif self._flat: # flat 按钮也设置 _text_icon_color
                self._apply_flat_defaults()
            elif self._level:
                self._apply_info_defaults(self._level)
                self.recalculate_text_color() # 信息按钮也可能需要根据背景重新计算文字颜色
            else:
                # 普通按钮
                self._apply_theme_defaults() 
                self.recalculate_text_color()
        else:
            # 禁用状态
            self._text_icon_color = QColor(160, 160, 160) if not tm.is_dark_mode() else QColor(120, 120, 120) # 恢复灰色
            # 对于链接按钮，其_apply_link_defaults会在_update_style调用时被调用，
            # 它内部会根据 isEnabled() 再次设定正确的 _text_icon_color 和 QSS。
            # 所以这里的统一设置为灰色对于链接按钮来说只是一个中间状态，
            # _apply_link_defaults 会最终决定链接按钮的禁用颜色。

        self._update_icon_color() # 基于更新后的 _text_icon_color 更新图标
        self._update_style()      # 应用样式表 (QSS)，这里会根据是否禁用设置 QSS 中的 color
        self.update()             # 请求重绘，使用 QSS 和 _text_icon_color (通过paintEvent)

        if self._glow_effect is not None:
            if enabled:
                self._glow_effect.set_state("normal", animate=False)
            else:
                self._glow_effect.set_state("disabled", animate=False)

    # -----------------------------------------------------------------
    # 链接和级别公共方法
    # -----------------------------------------------------------------
    def set_link(self, value: bool):
        if self._button_type == "toggle" and value:
            raise ValueError("选中按钮不可与链接同时启用")
        if self._link == value:
            return
        if value and (self._emphasized or self._flat):
            raise ValueError("链接按钮不可与强调或无边框同时启用")
        
        self._link = value # 设置实际状态变量应在调用相关 apply 方法之前或之后保持一致
                          # 这里选择在应用颜色前，因为 _apply_link_defaults 可能依赖它
                          # 但 _update_style 也依赖它，所以顺序需小心。
                          # 原始代码是 self._link = value 在最后，_update_style()之前

        if value:
            self._emphasized = False
            self._flat = False
            self._level = None
            self._apply_link_defaults() # _apply_link_defaults 内部已处理禁用状态的QSS和_text_icon_color
        else:
            self._apply_theme_defaults()
        
        # self._link = value # 移到前面或保持在这里，并确保 _update_style 正确工作
        # 对于链接按钮，_apply_link_defaults 会设置特定样式。如果取消链接，_update_style 会应用通用样式。
        # _ensure_disabled_color_if_needed 会在 _apply_theme_defaults 之后修正颜色（如果取消链接且禁用）
        self._ensure_disabled_color_if_needed()
        self._update_style() # _update_style 会根据 self._link 的值决定是否调用 _apply_link_defaults
        self.update()

    def set_level(self, level: str | None):
        if self._button_type == "toggle" and level:
            raise ValueError("选中按钮不可与信息按钮(level) 同时启用")
        level = level if level else None
        if level == self._level:
            return
        if level and (self._emphasized or self._link):
            raise ValueError("信息按钮不可与强调或链接同时启用")

        self._level = level if level in self.INFO_COLORS else None
        if self._level:
            # 禁用其他设置
            self._emphasized = False
            self._link = False
            self._flat = False
            self._apply_info_defaults(self._level)
        else:
            self._apply_theme_defaults()
        
        self._ensure_disabled_color_if_needed()
        self._update_style()
        self.update() # 添加显式 update

    # --------------- Rounded defaults -----------------
    def _apply_rounded_defaults(self):
        """应用圆角按钮的默认样式"""
        tm = ThemeManager.instance()
        # 色彩同普通按钮
        self._apply_theme_defaults()
        # 样式将在 _update_style 设置圆角/padding

        # 应用样式前
        if not self._rounded and self._glow_effect is not None:
            # 移除默认阴影
            self._shadow_eff = None

    # rounded toggle
    def set_rounded(self, value: bool):
        if self._rounded == value:
            return
        if value and (self._flat or self._link):
            raise ValueError("圆角按钮不可与无边框或链接同时启用")
        self._rounded = value
        if value:
            self._flat = False
            self._link = False
            self._apply_rounded_defaults()
        else:
            self._apply_theme_defaults()
        
        self._ensure_disabled_color_if_needed()
        self._update_style()
        self.update() # 添加显式 update

    # --------------- Glow defaults -----------------
    def _apply_glow_defaults(self, color_str: str):
        """应用辉光按钮默认样式

        参数:
            color_str: 辉光颜色，HEX格式
        """
        # 辉光设置器
        from ...common.effects import AnimatedGlowEffect
        # 移除默认阴影
        self.setGraphicsEffect(None)
        try:
            self._glow_effect = AnimatedGlowEffect(self, glow_color=QColor(color_str))
            # 替换阴影占位对象，避免后续动画访问已删除阴影
            self._shadow_effect = _NullShadow()
        except Exception as e:
            print("glow create error", e)

    # glow setter
    def set_glow_color(self, color_str: str | None):
        if color_str == self._glow_color_str:
            return
        if color_str and (self._flat or self._link):
            raise ValueError("辉光按钮不可与无边框或链接同时启用")
        self._glow_color_str = color_str
        if color_str:
            self._apply_glow_defaults(color_str)
        else:
            # 移除辉光还原阴影
            self.setGraphicsEffect(None)
            from ...common.effects import AnimatedShadowEffect
            self._shadow_effect = AnimatedShadowEffect(self)
            self._glow_effect = None

    # -----------------------------------------------------------------
    # 按钮类型：Toggle 支持
    # -----------------------------------------------------------------
    def _init_toggle_button(self):
        """初始化 Toggle 按钮行为。"""
        # 可切换
        self.setCheckable(True)

        # 处理主题变化的选中颜色同步
        ThemeManager.instance().theme_changed.connect(self._on_theme_color_changed)

        # 连接状态变化
        self.toggled.connect(self._handle_toggle_state_change)

        # 初始根据当前状态刷新颜色
        self._handle_toggle_state_change(self.isChecked())

    def _handle_toggle_state_change(self, checked: bool):
        """切换状态回调，更新配色。"""
        old_color = self._current_color  # 动画起始颜色

        # ------------------- 特例：无边框(toggle+flat) -------------------
        if self._flat:
            # 目标文字颜色：选中 -> 主题色 / 未选中 -> flat 默认
            if checked:
                target_text_color = self._checked_color
            else:
                # 恢复到未选中基准色
                target_text_color = getattr(self, "_flat_base_color", QColor("#333333"))

            # 动画文字颜色
            self._transition.color_change(
                self,
                b"textColor",
                self._text_icon_color,
                target_text_color,
                200,
                QEasingCurve.Type.OutCubic,
            )

            # 背景始终透明
            self._normal_color = QColor(0, 0, 0, 0)
            self._hover_color = QColor(0, 0, 0, 0)
            self._pressed_color = QColor(0, 0, 0, 0)

            # 更新存储值
            self._text_icon_color = target_text_color
            self._update_icon_color()
            self.update()

            # 更新 flat 默认 / hover 颜色，确保移入移出保持一致
            self._flat_default_color = target_text_color
            self._flat_hover_color = target_text_color.darker(115)
            return

        if checked:
            self._normal_color = self._checked_color
            self._hover_color = self._checked_color.lighter(110)
            self._pressed_color = self._checked_color.darker(110)
        else:
            # 恢复普通/flat 等逻辑，不立即更新 _current_color
            if self._emphasized:
                base_color = ThemeManager.instance().get_theme_color()
                self._normal_color = base_color
                self._hover_color = base_color.lighter(125)
                self._pressed_color = base_color.darker(125)
            elif self._flat:
                # 无边框模式保持透明背景
                self._normal_color = QColor(0, 0, 0, 0)
                self._hover_color = QColor(0, 0, 0, 0)
                self._pressed_color = QColor(0, 0, 0, 0)
            elif self._link:
                self._normal_color = QColor(0, 0, 0, 0)
                self._hover_color = QColor(0, 0, 0, 0)
                self._pressed_color = QColor(0, 0, 0, 0)
            elif self._level:
                n, h, p, *_ = self.INFO_COLORS[self._level]
                self._normal_color, self._hover_color, self._pressed_color = n, h, p
            else:
                tm = ThemeManager.instance()
                if tm.is_dark_mode():
                    self._normal_color = QColor(60, 60, 60)
                    self._hover_color = self._normal_color.lighter(115)
                    self._pressed_color = self._normal_color.darker(115)
                else:
                    self._normal_color = QColor(248, 248, 248)
                    self._hover_color = QColor(230, 230, 230)
                    self._pressed_color = QColor(210, 210, 210)

        # 计算并应用文字/图标颜色 (目标阶段)
        target_text_icon_color = self._calculate_best_text_color(self._normal_color)

        # 先将当前颜色恢复到 old_color 以便动画
        self._current_color = old_color
        # 触发背景色动画
        self._start_color_animation(self._normal_color)

        # 同步文字颜色到目标值
        self._text_icon_color = target_text_icon_color
        self._update_icon_color()
        self.update()

    def set_checked_color(self, color):
        """外部接口：设置切换选中颜色。"""
        self._checked_color = QColor(color)
        if self._button_type == "toggle" and self.isChecked():
            self._handle_toggle_state_change(True)

    def get_checked_color(self):  # noqa: D401
        """获取切换按钮选中颜色。"""
        return self._checked_color

    def _on_theme_color_changed(self):
        """主题色变化时同步 toggle 选中颜色。"""
        self._checked_color = ThemeManager.instance().get_theme_color()
        if self._button_type == "toggle" and self.isChecked():
            self._handle_toggle_state_change(True)

    # -----------------------------------------------------------------
    # 按钮类型：Dropdown 支持
    # -----------------------------------------------------------------
    def _init_dropdown_button(self):
        """初始化 Dropdown 按钮行为。"""
        from ...common.elements.menu import RoundMenu  # 避免循环导入
        # 无默认菜单
        self._menu: RoundMenu | None = None

        # 显示自定义菜单策略
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)

        # 点击、右键均显示菜单
        self.clicked.connect(self._on_dropdown_clicked)
        self.customContextMenuRequested.connect(self._on_dropdown_custom_menu_requested)

    # ---------------- Dropdown 交互 -----------------
    def set_menu(self, menu):
        """为下拉按钮设置菜单 (RoundMenu)。"""
        from ...common.elements.menu import RoundMenu

        if menu is not None and not isinstance(menu, RoundMenu):
            raise TypeError("菜单必须是 RoundMenu 或其子类")
        self._menu = menu
        # 同步菜单背景色 - RoundMenu 现在会自动从 ThemeManager 同步，不再需要下面这行
        # if self._menu is not None and hasattr(self, "_normal_color"):
        #     self._menu.set_colors(bg_color=self._normal_color.name())  # type: ignore[operator]

    def menu(self):
        """返回当前绑定的菜单对象。"""
        return self._menu

    def _on_dropdown_clicked(self):
        if self._menu is not None:
            # 弹出在按钮下方左对齐
            self._show_dropdown_menu()

    def _on_dropdown_custom_menu_requested(self, _pos):
        if self._menu is not None:
            self._show_dropdown_menu()

    def _show_dropdown_menu(self):
        try:
            from ...common.elements.menu import PopupPosition, AlignPoint

            self._menu.popup(
                position=None,
                target_widget=self,
                pos_type=PopupPosition.BOTTOM,
                align_point=AlignPoint.TOP_LEFT,
            )
        except Exception:
            # 兜底：直接使用QMenu exec在按钮下方
            global_pos = self.mapToGlobal(self.rect().bottomLeft())
            self._menu.exec(global_pos)

    # ---------------- Dropdown 绘制 -----------------
    def _get_dropdown_arrow_icon(self):
        color_name = self._text_icon_color.name() if hasattr(self, "_text_icon_color") else "#000000"
        if self._arrow_shape == "triangle":
            return get_icon("chevron-down", color=color_name)
        return get_icon("more-vertical", color=color_name)

    def _draw_dropdown_arrow(self, painter):
        rect = self.rect()
        arrow_size = min(12, int(rect.height() * 0.5))
        arrow_x = rect.right() - arrow_size - 6  # 右侧留 6px
        arrow_y = (rect.height() - arrow_size) // 2
        
        # 注意：不需要单独应用_content_offset，因为painter已经在paintEvent中被平移了
        # 直接绘制箭头即可，它会跟随整个内容一起移动
        painter.drawPixmap(
            arrow_x,
            arrow_y,
            self._get_dropdown_arrow_icon().pixmap(QSize(arrow_size, arrow_size)),
        )

    # -----------------------------------------------------------------
    # 按钮类型：Split 支持
    # -----------------------------------------------------------------
    def _init_split_button(self):
        """初始化拆分按钮行为。"""
        # 拆分按钮需要监听鼠标移动来跟踪悬停状态
        self.setMouseTracking(True)
        
        # 默认无菜单
        self._menu = None

    def set_split_ratio(self, ratio: float):
        """设置拆分按钮左右比例。

        参数:
            ratio: 左侧按钮占总宽度的比例，范围 0.0-1.0
        """
        if 0.0 < ratio < 1.0:
            self._split_ratio = ratio
            self.update()

    def get_split_ratio(self):
        """获取拆分按钮左右比例"""
        return self._split_ratio

    def _is_point_in_left_part(self, pos: QPoint) -> bool:
        """判断点击位置是否在左侧部分
        
        参数:
            pos: 相对于按钮的坐标
            
        返回:
            是否在左侧部分
        """
        split_x = int(self.width() * self._split_ratio)
        return pos.x() < split_x

    def _get_split_part_at_pos(self, pos: QPoint) -> str:
        """获取指定位置属于按钮的哪个部分
        
        参数:
            pos: 相对于按钮的坐标
            
        返回:
            "left" 或 "right"
        """
        return "left" if self._is_point_in_left_part(pos) else "right"

    def mouseMoveEvent(self, event):
        """鼠标移动事件，追踪拆分按钮的悬停部分"""
        if self._button_type == "split" and self.isEnabled():
            # 获取当前悬停的部分
            current_part = self._get_split_part_at_pos(event.pos())
            if current_part != self._split_hover_part:
                # 悬停部分发生变化
                self._split_hover_part = current_part
                # 更新显示效果
                self.update()
        
        # 调用父类方法处理其他逻辑
        super().mouseMoveEvent(event)

    def mousePressEvent(self, event):
        """鼠标按下事件，记录拆分按钮的按下部分"""
        if self._button_type == "split" and self.isEnabled() and event.button() == Qt.MouseButton.LeftButton:
            # 记录按下的部分
            current_part = self._get_split_part_at_pos(event.pos())
            self._split_pressed_part = current_part
            
            # 根据按下的部分应用内容偏移动画
            if current_part == "left":
                self._transition.point_change(
                    self,
                    b"splitLeftOffset",
                    self._split_left_offset,
                    QPointF(0, 2),
                    100,
                    QEasingCurve.Type.OutCubic,
                )
            else:  # "right"
                self._transition.point_change(
                    self,
                    b"splitRightOffset",
                    self._split_right_offset,
                    QPointF(0, 2),
                    100,
                    QEasingCurve.Type.OutCubic,
                )
            
            self.update()
        
        # 调用父类方法处理其他逻辑，但对于拆分按钮不传递到基类的内容偏移
        if self._button_type != "split":
            super().mousePressEvent(event)
        else:
            # 对于拆分按钮，仅调用QPushButton的基类方法，跳过AnimatedButton的内容偏移
            QPushButton.mousePressEvent(self, event)

    def mouseReleaseEvent(self, event):
        """鼠标释放事件，处理拆分按钮的点击行为"""
        if self._button_type == "split" and self.isEnabled() and event.button() == Qt.MouseButton.LeftButton:
            # 获取释放位置所在部分
            release_part = self._get_split_part_at_pos(event.pos())
            
            # 重置内容偏移，无论是哪个部分
            if self._split_pressed_part == "left":
                self._transition.point_change(
                    self,
                    b"splitLeftOffset",
                    self._split_left_offset,
                    QPointF(0, 0),
                    100,
                    QEasingCurve.Type.OutCubic,
                )
            elif self._split_pressed_part == "right":
                self._transition.point_change(
                    self,
                    b"splitRightOffset",
                    self._split_right_offset,
                    QPointF(0, 0),
                    100,
                    QEasingCurve.Type.OutCubic,
                )
            
            # 如果在同一部分按下和释放，执行相应操作
            if self._split_pressed_part == release_part:
                if release_part == "left":
                    # 左侧按钮点击触发 clicked 信号
                    self.clicked.emit()
                elif release_part == "right" and self._menu is not None:
                    # 右侧按钮点击显示菜单
                    self._show_dropdown_menu()
            
            # 重置按下状态
            self._split_pressed_part = None
            # 更新悬停部分
            self._split_hover_part = self._get_split_part_at_pos(event.pos())
            self.update()
        
        # 调用父类方法处理其他逻辑，但对于拆分按钮不传递到基类的内容偏移
        if self._button_type != "split":
            super().mouseReleaseEvent(event)
        else:
            # 对于拆分按钮，仅调用QPushButton的基类方法，跳过AnimatedButton的内容偏移
            QPushButton.mouseReleaseEvent(self, event)

    def leaveEvent(self, event):
        """鼠标离开事件，重置拆分按钮状态"""
        if self._button_type == "split":
            # 重置内容偏移
            if self._split_left_offset != QPointF(0, 0):
                self._transition.point_change(
                    self,
                    b"splitLeftOffset",
                    self._split_left_offset,
                    QPointF(0, 0),
                    100,
                    QEasingCurve.Type.OutCubic,
                )
            if self._split_right_offset != QPointF(0, 0):
                self._transition.point_change(
                    self,
                    b"splitRightOffset",
                    self._split_right_offset,
                    QPointF(0, 0),
                    100,
                    QEasingCurve.Type.OutCubic,
                )
            
            self._split_hover_part = None
            self._split_pressed_part = None
            self.update()
        
        # 调用父类方法处理其他逻辑
        super().leaveEvent(event)

    def _draw_split_button(self, painter: QPainter):
        """绘制拆分按钮的特殊元素"""
        rect = self.rect()
        split_x = int(rect.width() * self._split_ratio)
        
        # 保存当前绘图状态
        painter.save()
        
        # 绘制左侧内容（文字和图标）
        painter.save()
        # 应用左侧内容偏移
        painter.translate(self._split_left_offset)
        # 设置左侧裁剪区域
        left_clip = QPainterPath()
        left_clip.addRect(QRectF(0, 0, split_x, rect.height()))
        painter.setClipPath(left_clip)
        # 调用临时按钮绘制左侧内容
        tmp_btn = QPushButton(self.text(), self)
        tmp_btn.setIcon(self.icon())
        tmp_btn.setIconSize(self.iconSize())
        tmp_btn.resize(self.size())
        tmp_btn.setStyleSheet(
            f"""
            background-color: transparent;
            border: none;
            color: {self._text_icon_color.name()};
        """
        )
        tmp_btn.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        tmp_btn.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        tmp_btn.render(painter)
        painter.restore()
        
        # 绘制分隔线
        # 设置分隔线颜色，根据主题模式选择半透明的前景色
        line_color = self._text_icon_color.lighter(150) if ThemeManager.instance().is_dark_mode() else self._text_icon_color.darker(150)
        line_color.setAlpha(100)  # 半透明
        painter.setPen(line_color)
        
        # 绘制垂直分隔线
        painter.drawLine(split_x, 5, split_x, rect.height() - 5)
        
        # 绘制右侧箭头
        painter.save()
        # 应用右侧内容偏移
        painter.translate(self._split_right_offset)
        # 设置右侧裁剪区域
        right_clip = QPainterPath()
        right_clip.addRect(QRectF(split_x, 0, rect.width() - split_x, rect.height()))
        painter.setClipPath(right_clip)
        
        # 在右侧绘制下拉箭头
        arrow_size = min(12, int(rect.height() * 0.3))
        arrow_x = rect.left() + split_x + (rect.width() - split_x - arrow_size) // 2
        arrow_y = (rect.height() - arrow_size) // 2
        painter.drawPixmap(
            arrow_x,
            arrow_y,
            self._get_dropdown_arrow_icon().pixmap(QSize(arrow_size, arrow_size)),
        )
        painter.restore()
        
        # 根据悬停和按下状态绘制背景色
        if self._split_hover_part or self._split_pressed_part:
            # 设置透明度
            painter.setOpacity(0.2 if self._split_hover_part else 0.3)
            
            # 根据状态选择区域
            part = self._split_pressed_part or self._split_hover_part
            
            # 使用当前主题的高亮色或悬停颜色
            hover_color = self._hover_color if hasattr(self, "_hover_color") else QColor(100, 100, 100, 50)
            painter.setBrush(hover_color)
            painter.setPen(Qt.PenStyle.NoPen)
            
            # 绘制区域
            radius = 16 if self._rounded else 4
            if part == "left":
                # 左侧部分：左边是圆角，右边是直角
                path = QPainterPath()
                path.moveTo(radius, 0)
                path.arcTo(0, 0, radius * 2, radius * 2, 90, 90)
                path.lineTo(0, rect.height() - radius)
                path.arcTo(0, rect.height() - radius * 2, radius * 2, radius * 2, 180, 90)
                path.lineTo(split_x, rect.height())
                path.lineTo(split_x, 0)
                path.closeSubpath()
                painter.drawPath(path)
            else:
                # 右侧部分：右边是圆角，左边是直角
                path = QPainterPath()
                path.moveTo(split_x, 0)
                path.lineTo(rect.width() - radius, 0)
                path.arcTo(rect.width() - radius * 2, 0, radius * 2, radius * 2, 90, -90)
                path.lineTo(rect.width(), rect.height() - radius)
                path.arcTo(rect.width() - radius * 2, rect.height() - radius * 2, radius * 2, radius * 2, 0, -90)
                path.lineTo(split_x, rect.height())
                path.closeSubpath()
                painter.drawPath(path)
        
        painter.restore()

    # -----------------------------------------------------------------
    # 添加属性动画支持
    # -----------------------------------------------------------------
    @pyqtProperty(QPointF)
    def splitLeftOffset(self):
        return self._split_left_offset

    @splitLeftOffset.setter
    def splitLeftOffset(self, value: QPointF):
        self._split_left_offset = value
        self.update()

    @pyqtProperty(QPointF)
    def splitRightOffset(self):
        return self._split_right_offset

    @splitRightOffset.setter
    def splitRightOffset(self, value: QPointF):
        self._split_right_offset = value
        self.update()

    # -----------------------------------------------------------------
    # 重载 paintEvent – 追加 dropdown / split 箭头
    # -----------------------------------------------------------------
    def paintEvent(self, event):  # type: ignore[override]
        if self._button_type == "split":
            # 对于拆分按钮，我们使用自定义绘制逻辑
            painter = QPainter(self)
            if not painter.isActive():
                return
            
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            
            # 绘制背景
            radius = 4
            if hasattr(self, "_rounded") and getattr(self, "_rounded"):
                radius = 16
            path = QPainterPath()
            path.addRoundedRect(QRectF(self.rect()), radius, radius)
            painter.setClipPath(path)
            painter.fillRect(self.rect(), QBrush(self._current_color))
            
            # 绘制拆分按钮的特殊元素
            self._draw_split_button(painter)
            
            painter.end()
        else:
            # 其他按钮类型使用原始逻辑，包括dropdown
            super().paintEvent(event)
            
            # 对于dropdown按钮，在绘制文字图标后，在同一个偏移状态下绘制箭头
            if self._button_type == "dropdown" and self._menu is not None:
                painter = QPainter(self)
                if not painter.isActive():
                    return
                painter.setRenderHint(QPainter.RenderHint.Antialiasing)
                
                # 应用与文字图标相同的偏移
                painter.translate(self._content_offset)
                
                # 绘制下拉箭头
                self._draw_dropdown_arrow(painter)
                painter.end()


# 保持向后兼容，导出 NormalButton 名称
NormalButton = ForgeButton
Button = ForgeButton