"""按钮动画基类（独立版本）。"""

from PyQt6.QtCore import QEasingCurve, QPoint, QPointF, pyqtProperty, QRectF, Qt
from PyQt6.QtGui import QColor, QBrush, QPainter, QPainterPath
from PyQt6.QtWidgets import QPushButton, QWidget, QToolButton

from ...common.animations import SmoothTransition
from ...common.effects import AnimatedShadowEffect
from ..window.theme import ThemeManager
from .mixins import ColorMixin


class AnimatedButton(ColorMixin, QPushButton):
    """带有阴影与背景色动画的 QPushButton 基类。"""

    def __init__(self, text: str = "", parent: QWidget | None = None):
        super().__init__(text, parent)

        self._transition = SmoothTransition(self)
        self._shadow_effect = AnimatedShadowEffect(self)

        # 默认颜色（三态）
        self._normal_color = QColor(248, 248, 248)
        self._hover_color = QColor(230, 230, 230)
        self._pressed_color = QColor(210, 210, 210)
        self._current_color = self._normal_color

        # 内容偏移（按压动画）
        self._content_offset = QPointF(0, 0)

        # 前景色
        self._text_icon_color = self._calculate_best_text_color(self._current_color)
        self._initialized = True

        self.setAutoFillBackground(False)
        self.installEventFilter(self)

        # 主题适配
        self._apply_theme_defaults()
        ThemeManager.instance().theme_changed.connect(self._on_theme_changed)

    # ------------------------------------------------------------------
    # 主题颜色
    # ------------------------------------------------------------------
    def _apply_theme_defaults(self):
        tm = ThemeManager.instance()
        if tm.is_dark_mode():
            self._normal_color = QColor(60, 60, 60)
            self._hover_color = self._normal_color.lighter(115)
            self._pressed_color = self._normal_color.darker(115)
        else:
            self._normal_color = QColor(248, 248, 248)
            self._hover_color = QColor(230, 230, 230)
            self._pressed_color = QColor(210, 210, 210)
        self._current_color = self._normal_color
        self.recalculate_text_color()
        self.update()

    def _on_theme_changed(self):
        if getattr(self, "_follow_theme_background", True):
            self._apply_theme_defaults()

    # ------------------------------------------------------------------
    # 事件过滤器（悬停/按压动画）
    # ------------------------------------------------------------------
    def eventFilter(self, watched, event):
        if watched == self and self.isEnabled():
            t = event.type()
            if t == event.Type.Enter:
                self._start_color_animation(self._hover_color)
                self._shadow_effect.set_state("hover")
            elif t == event.Type.Leave:
                self._start_color_animation(self._normal_color)
                self._start_content_animation(QPointF(0, 0))
                self._shadow_effect.set_state("normal")
            elif t == event.Type.MouseButtonPress:
                self._start_color_animation(self._pressed_color)
                self._start_content_animation(QPointF(0, 2))
                self._shadow_effect.set_state("pressed")
            elif t == event.Type.MouseButtonRelease:
                self._start_color_animation(self._hover_color)
                self._start_content_animation(QPointF(0, 0))
                self._shadow_effect.set_state("hover")
        return super().eventFilter(watched, event)

    # ------------------------------------------------------------------
    # 动画封装
    # ------------------------------------------------------------------
    def _start_color_animation(self, end_color: QColor):
        self._transition.color_change(
            self,
            b"color",
            self._current_color,
            end_color,
            200,
            QEasingCurve.Type.OutCubic,
        )

    def _start_content_animation(self, end_offset: QPointF):
        self._transition.point_change(
            self,
            b"contentOffset",
            self._content_offset,
            end_offset,
            100,
            QEasingCurve.Type.OutCubic,
        )

    # ------------------------------------------------------------------
    # 绘制
    # ------------------------------------------------------------------
    def paintEvent(self, event):  # noqa: D401
        painter = QPainter(self)
        if not painter.isActive():
            return
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        radius = 4
        if hasattr(self, "_rounded") and getattr(self, "_rounded"):
            radius = 16
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()), radius, radius)
        painter.setClipPath(path)
        painter.fillRect(self.rect(), QBrush(self._current_color))

        painter.save()
        painter.translate(self._content_offset)
        self._paint_button_content(painter)
        painter.restore()

    # ------------------------------------------------------------------
    # 内部绘制文字 / 图标
    # ------------------------------------------------------------------
    def _paint_button_content(self, painter: QPainter):
        """使用临时 QPushButton 渲染，与旧实现保持一致。"""
        tmp_btn = QPushButton(self.text(), self)
        tmp_btn.setIcon(self.icon())
        tmp_btn.setIconSize(self.iconSize())
        tmp_btn.resize(self.size())

        # 前景色
        tmp_btn.setStyleSheet(
            f"""
            background-color: transparent;
            border: none;
            color: {self._text_icon_color.name()};
        """
        )

        tmp_btn.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        tmp_btn.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        tmp_btn.render(painter)

    # ------------------------------------------------------------------
    # 属性动画支持
    # ------------------------------------------------------------------
    @pyqtProperty(QColor)
    def color(self):  # type: ignore[override]
        return self._current_color

    @color.setter  # type: ignore[override]
    def color(self, value: QColor):
        self._current_color = value
        self.update()

    @pyqtProperty(QPointF)
    def contentOffset(self):  # noqa: N802
        return self._content_offset

    @contentOffset.setter
    def contentOffset(self, value: QPointF):  # noqa: N802
        self._content_offset = value
        self.update()

    # ------------------------------------------------------------------
    # 启用 / 禁用同步阴影效果
    # ------------------------------------------------------------------
    def setEnabled(self, enabled: bool):  # type: ignore[override]
        super().setEnabled(enabled)
        if enabled:
            self._shadow_effect.set_state("normal")
        else:
            self._shadow_effect.set_state("disabled", animate=False)

    # ------------------------------------------------------------------
    # 接口供 IconMixin 使用
    # ------------------------------------------------------------------
    def get_text_icon_color(self):
        return self._text_icon_color 

from PyQt6.QtCore import QEasingCurve, QPoint, QPointF, pyqtProperty, QRectF, Qt
from PyQt6.QtGui import QColor, QBrush, QPainter, QPainterPath
from PyQt6.QtWidgets import QPushButton, QWidget, QToolButton

from ...common.animations import SmoothTransition
from ...common.effects import AnimatedShadowEffect
from ..window.theme import ThemeManager
from .mixins import ColorMixin


class AnimatedButton(ColorMixin, QPushButton):
    """带有阴影与背景色动画的 QPushButton 基类。"""

    def __init__(self, text: str = "", parent: QWidget | None = None):
        super().__init__(text, parent)

        self._transition = SmoothTransition(self)
        self._shadow_effect = AnimatedShadowEffect(self)

        # 默认颜色（三态）
        self._normal_color = QColor(248, 248, 248)
        self._hover_color = QColor(230, 230, 230)
        self._pressed_color = QColor(210, 210, 210)
        self._current_color = self._normal_color

        # 内容偏移（按压动画）
        self._content_offset = QPointF(0, 0)

        # 前景色
        self._text_icon_color = self._calculate_best_text_color(self._current_color)
        self._initialized = True

        self.setAutoFillBackground(False)
        self.installEventFilter(self)

        # 主题适配
        self._apply_theme_defaults()
        ThemeManager.instance().theme_changed.connect(self._on_theme_changed)

    # ------------------------------------------------------------------
    # 主题颜色
    # ------------------------------------------------------------------
    def _apply_theme_defaults(self):
        tm = ThemeManager.instance()
        if tm.is_dark_mode():
            self._normal_color = QColor(60, 60, 60)
            self._hover_color = self._normal_color.lighter(115)
            self._pressed_color = self._normal_color.darker(115)
        else:
            self._normal_color = QColor(248, 248, 248)
            self._hover_color = QColor(230, 230, 230)
            self._pressed_color = QColor(210, 210, 210)
        self._current_color = self._normal_color
        self.recalculate_text_color()
        self.update()

    def _on_theme_changed(self):
        if getattr(self, "_follow_theme_background", True):
            self._apply_theme_defaults()

    # ------------------------------------------------------------------
    # 事件过滤器（悬停/按压动画）
    # ------------------------------------------------------------------
    def eventFilter(self, watched, event):
        if watched == self and self.isEnabled():
            t = event.type()
            if t == event.Type.Enter:
                self._start_color_animation(self._hover_color)
                self._shadow_effect.set_state("hover")
            elif t == event.Type.Leave:
                self._start_color_animation(self._normal_color)
                self._start_content_animation(QPointF(0, 0))
                self._shadow_effect.set_state("normal")
            elif t == event.Type.MouseButtonPress:
                self._start_color_animation(self._pressed_color)
                self._start_content_animation(QPointF(0, 2))
                self._shadow_effect.set_state("pressed")
            elif t == event.Type.MouseButtonRelease:
                self._start_color_animation(self._hover_color)
                self._start_content_animation(QPointF(0, 0))
                self._shadow_effect.set_state("hover")
        return super().eventFilter(watched, event)

    # ------------------------------------------------------------------
    # 动画封装
    # ------------------------------------------------------------------
    def _start_color_animation(self, end_color: QColor):
        self._transition.color_change(
            self,
            b"color",
            self._current_color,
            end_color,
            200,
            QEasingCurve.Type.OutCubic,
        )

    def _start_content_animation(self, end_offset: QPointF):
        self._transition.point_change(
            self,
            b"contentOffset",
            self._content_offset,
            end_offset,
            100,
            QEasingCurve.Type.OutCubic,
        )

    # ------------------------------------------------------------------
    # 绘制
    # ------------------------------------------------------------------
    def paintEvent(self, event):  # noqa: D401
        painter = QPainter(self)
        if not painter.isActive():
            return
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        radius = 4
        if hasattr(self, "_rounded") and getattr(self, "_rounded"):
            radius = 16
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()), radius, radius)
        painter.setClipPath(path)
        painter.fillRect(self.rect(), QBrush(self._current_color))

        painter.save()
        painter.translate(self._content_offset)
        self._paint_button_content(painter)
        painter.restore()

    # ------------------------------------------------------------------
    # 内部绘制文字 / 图标
    # ------------------------------------------------------------------
    def _paint_button_content(self, painter: QPainter):
        """使用临时 QPushButton 渲染，与旧实现保持一致。"""
        tmp_btn = QPushButton(self.text(), self)
        tmp_btn.setIcon(self.icon())
        tmp_btn.setIconSize(self.iconSize())
        tmp_btn.resize(self.size())

        # 前景色
        tmp_btn.setStyleSheet(
            f"""
            background-color: transparent;
            border: none;
            color: {self._text_icon_color.name()};
        """
        )

        tmp_btn.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        tmp_btn.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        tmp_btn.render(painter)

    # ------------------------------------------------------------------
    # 属性动画支持
    # ------------------------------------------------------------------
    @pyqtProperty(QColor)
    def color(self):  # type: ignore[override]
        return self._current_color

    @color.setter  # type: ignore[override]
    def color(self, value: QColor):
        self._current_color = value
        self.update()

    @pyqtProperty(QPointF)
    def contentOffset(self):  # noqa: N802
        return self._content_offset

    @contentOffset.setter
    def contentOffset(self, value: QPointF):  # noqa: N802
        self._content_offset = value
        self.update()

    # ------------------------------------------------------------------
    # 启用 / 禁用同步阴影效果
    # ------------------------------------------------------------------
    def setEnabled(self, enabled: bool):  # type: ignore[override]
        super().setEnabled(enabled)
        if enabled:
            self._shadow_effect.set_state("normal")
        else:
            self._shadow_effect.set_state("disabled", animate=False)

    # ------------------------------------------------------------------
    # 接口供 IconMixin 使用
    # ------------------------------------------------------------------
    def get_text_icon_color(self):
        return self._text_icon_color 
 