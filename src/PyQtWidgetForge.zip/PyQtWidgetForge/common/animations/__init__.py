"""
PyQtWidgetForge 通用动画模块

此模块包含可用于多个组件的动画效果
"""

from .transition import SmoothTransition

# 导出公共API
__all__ = [
    "SmoothTransition",
]
