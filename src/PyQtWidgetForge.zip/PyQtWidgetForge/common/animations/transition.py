"""
过渡动画模块

提供平滑的属性过渡动画效果
"""
import weakref

from PyQt6.QtCore import (
    QEasingCurve,
    QObject,
    QPoint,
    QPointF,
    QPropertyAnimation,
    QRect,
    QSize,
    QTimer,
    pyqtProperty,
)
from PyQt6.QtGui import QColor, QPainterPath
from PyQt6.QtWidgets import QWidget


class SmoothTransition(QObject):
    """
    平滑过渡动画类

    提供对QWidget属性的平滑过渡动画，支持多种属性类型和缓动曲线
    """

    def __init__(self, parent=None):
        """
        初始化平滑过渡动画对象

        参数:
            parent (QObject): 父对象
        """
        super().__init__(parent)
        self._animations = {}  # 存储所有动画对象
        self._target_refs = {}  # 存储目标对象的弱引用

    def animate(
        self,
        target,
        property_name,
        start_value,
        end_value,
        duration=300,
        easing_curve=QEasingCurve.Type.OutCubic,
        finished_callback=None,
    ):
        """
        创建并启动属性动画

        参数:
            target (QObject): 目标控件或对象
            property_name (str/bytes): 要动画的属性名称
            start_value: 起始值
            end_value: 结束值
            duration (int): 动画持续时间，单位毫秒
            easing_curve (QEasingCurve.Type): 缓动曲线类型
            finished_callback (callable): 动画完成时的回调函数

        返回:
            QPropertyAnimation: 创建的动画对象
        """
        # 检查目标对象是否有效
        if target is None:
            return None

        # 检查目标对象是否已被删除（C++对象）
        try:
            # 尝试访问一个基本属性来检测对象是否有效
            target.parent()
        except (RuntimeError, TypeError, AttributeError):
            # 如果抛出异常，说明C++对象已被删除或无效
            print(f"动画目标对象无效: {target}")
            return None

        # 创建属性动画
        try:
            animation = QPropertyAnimation(
                target,
                property_name.encode()
                if isinstance(property_name, str)
                else property_name,
            )

            # 设置动画参数
            animation.setStartValue(start_value)
            animation.setEndValue(end_value)
            animation.setDuration(duration)
            animation.setEasingCurve(easing_curve)

            # 连接完成信号
            if finished_callback:
                animation.finished.connect(finished_callback)

            # 保存动画引用（避免被垃圾回收）
            key = f"{id(target)}_{property_name}"
            self._animations[key] = animation

            # 保存目标对象的弱引用
            self._target_refs[key] = weakref.ref(
                target, lambda _: self._cleanup_animation(key)
            )

            # 连接完成信号以清理引用
            animation.finished.connect(lambda: self._cleanup_animation(key))

            # 启动动画
            animation.start()

            return animation
        except Exception as e:
            print(f"创建或启动动画时出错: {e}")
            return None

    def _cleanup_animation(self, key):
        """清理已完成的动画"""
        if key in self._animations:
            # 停止动画并移除引用
            animation = self._animations.pop(key)
            if animation.state() == QPropertyAnimation.State.Running:
                animation.stop()

        # 清理目标对象引用
        if key in self._target_refs:
            self._target_refs.pop(key)

    def stop_all(self):
        """停止所有动画"""
        for key, animation in list(self._animations.items()):
            try:
                if animation.state() == QPropertyAnimation.State.Running:
                    animation.stop()
            except RuntimeError:
                # 动画对象已被Qt删除
                pass
        self._animations.clear()
        self._target_refs.clear()

    def fade(
        self,
        widget,
        start_opacity,
        end_opacity,
        duration=300,
        easing_curve=QEasingCurve.Type.OutCubic,
        finished_callback=None,
    ):
        """
        淡入淡出动画

        参数:
            widget (QWidget): 目标控件
            start_opacity (float): 起始透明度 (0.0-1.0)
            end_opacity (float): 结束透明度 (0.0-1.0)
            duration (int): 动画持续时间，单位毫秒
            easing_curve (QEasingCurve.Type): 缓动曲线类型
            finished_callback (callable): 动画完成时的回调函数

        返回:
            QPropertyAnimation: 创建的动画对象
        """
        return self.animate(
            widget,
            "windowOpacity",
            start_opacity,
            end_opacity,
            duration,
            easing_curve,
            finished_callback,
        )

    def slide(
        self,
        widget,
        start_pos,
        end_pos,
        duration=300,
        easing_curve=QEasingCurve.Type.OutCubic,
        finished_callback=None,
    ):
        """
        滑动动画

        参数:
            widget (QWidget): 目标控件
            start_pos (QPoint): 起始位置
            end_pos (QPoint): 结束位置
            duration (int): 动画持续时间，单位毫秒
            easing_curve (QEasingCurve.Type): 缓动曲线类型
            finished_callback (callable): 动画完成时的回调函数

        返回:
            QPropertyAnimation: 创建的动画对象
        """
        return self.animate(
            widget, "pos", start_pos, end_pos, duration, easing_curve, finished_callback
        )

    def resize(
        self,
        widget,
        start_size,
        end_size,
        duration=300,
        easing_curve=QEasingCurve.Type.OutCubic,
        finished_callback=None,
    ):
        """
        大小调整动画

        参数:
            widget (QWidget): 目标控件
            start_size (QSize): 起始大小
            end_size (QSize): 结束大小
            duration (int): 动画持续时间，单位毫秒
            easing_curve (QEasingCurve.Type): 缓动曲线类型
            finished_callback (callable): 动画完成时的回调函数

        返回:
            QPropertyAnimation: 创建的动画对象
        """
        return self.animate(
            widget,
            "size",
            start_size,
            end_size,
            duration,
            easing_curve,
            finished_callback,
        )

    def geometry_change(
        self,
        widget,
        start_rect,
        end_rect,
        duration=300,
        easing_curve=QEasingCurve.Type.OutCubic,
        finished_callback=None,
    ):
        """
        几何变化动画（同时改变位置和大小）

        参数:
            widget (QWidget): 目标控件
            start_rect (QRect): 起始矩形区域
            end_rect (QRect): 结束矩形区域
            duration (int): 动画持续时间，单位毫秒
            easing_curve (QEasingCurve.Type): 缓动曲线类型
            finished_callback (callable): 动画完成时的回调函数

        返回:
            QPropertyAnimation: 创建的动画对象
        """
        return self.animate(
            widget,
            "geometry",
            start_rect,
            end_rect,
            duration,
            easing_curve,
            finished_callback,
        )

    def color_change(
        self,
        obj,
        property_name,
        start_color,
        end_color,
        duration=300,
        easing_curve=QEasingCurve.Type.OutCubic,
        finished_callback=None,
    ):
        """
        颜色变化动画

        参数:
            obj (QObject): 目标对象
            property_name (str): 要动画的属性名称
            start_color (QColor): 起始颜色
            end_color (QColor): 结束颜色
            duration (int): 动画持续时间，单位毫秒
            easing_curve (QEasingCurve.Type): 缓动曲线类型
            finished_callback (callable): 动画完成时的回调函数

        返回:
            QPropertyAnimation: 创建的动画对象
        """
        return self.animate(
            obj,
            property_name,
            start_color,
            end_color,
            duration,
            easing_curve,
            finished_callback,
        )

    def point_change(
        self,
        obj,
        property_name,
        start_point,
        end_point,
        duration=300,
        easing_curve=QEasingCurve.Type.OutCubic,
        finished_callback=None,
    ):
        """
        点位置变化动画

        参数:
            obj (QObject): 目标对象
            property_name (str): 要动画的属性名称
            start_point (QPoint/QPointF): 起始点位置
            end_point (QPoint/QPointF): 结束点位置
            duration (int): 动画持续时间，单位毫秒
            easing_curve (QEasingCurve.Type): 缓动曲线类型
            finished_callback (callable): 动画完成时的回调函数

        返回:
            QPropertyAnimation: 创建的动画对象
        """
        return self.animate(
            obj,
            property_name,
            start_point,
            end_point,
            duration,
            easing_curve,
            finished_callback,
        )

    def path_change(
        self,
        obj,
        property_name,
        start_path,
        end_path,
        duration=300,
        easing_curve=QEasingCurve.Type.OutCubic,
        finished_callback=None,
    ):
        """
        路径变化动画

        参数:
            obj (QObject): 目标对象
            property_name (str): 要动画的属性名称
            start_path (QPainterPath): 起始路径
            end_path (QPainterPath): 结束路径
            duration (int): 动画持续时间，单位毫秒
            easing_curve (QEasingCurve.Type): 缓动曲线类型
            finished_callback (callable): 动画完成时的回调函数

        返回:
            QPropertyAnimation: 创建的动画对象
        """
        return self.animate(
            obj,
            property_name,
            start_path,
            end_path,
            duration,
            easing_curve,
            finished_callback,
        )

    def shadow_offset_change(
        self,
        effect,
        start_offset,
        end_offset,
        duration=300,
        easing_curve=QEasingCurve.Type.OutCubic,
        finished_callback=None,
    ):
        """
        阴影偏移变化动画

        参数:
            effect (QGraphicsDropShadowEffect): 阴影效果对象
            start_offset (float/QPointF): 起始偏移
            end_offset (float/QPointF): 结束偏移
            duration (int): 动画持续时间，单位毫秒
            easing_curve (QEasingCurve.Type): 缓动曲线类型
            finished_callback (callable): 动画完成时的回调函数

        返回:
            QPropertyAnimation: 创建的动画对象
        """
        # 检查效果对象是否有效
        if effect is None:
            return None

        # 安全检查，尝试访问effect的一个属性
        try:
            effect.offset()
        except RuntimeError:
            # C++对象已被Qt删除或无效
            print(f"阴影效果对象无效: {effect}")
            return None

        if isinstance(start_offset, (int, float)) and isinstance(
            end_offset, (int, float)
        ):
            # 如果是数值，则设置垂直偏移
            return self.animate(
                effect,
                "yOffset",
                float(start_offset),
                float(end_offset),
                duration,
                easing_curve,
                finished_callback,
            )
        else:
            # 如果是QPointF，则设置x和y偏移
            x_anim = self.animate(
                effect,
                "xOffset",
                start_offset.x(),
                end_offset.x(),
                duration,
                easing_curve,
                None,
            )
            y_anim = self.animate(
                effect,
                "yOffset",
                start_offset.y(),
                end_offset.y(),
                duration,
                easing_curve,
                finished_callback,
            )
            return y_anim  # 返回y轴动画，因为它带有完成回调

    def shadow_blur_change(
        self,
        effect,
        start_blur,
        end_blur,
        duration=300,
        easing_curve=QEasingCurve.Type.OutCubic,
        finished_callback=None,
    ):
        """
        阴影模糊半径变化动画

        参数:
            effect (QGraphicsDropShadowEffect): 阴影效果对象
            start_blur (float): 起始模糊半径
            end_blur (float): 结束模糊半径
            duration (int): 动画持续时间，单位毫秒
            easing_curve (QEasingCurve.Type): 缓动曲线类型
            finished_callback (callable): 动画完成时的回调函数

        返回:
            QPropertyAnimation: 创建的动画对象
        """
        # 检查效果对象是否有效
        if effect is None:
            return None

        # 安全检查，尝试访问effect的一个属性
        try:
            effect.blurRadius()
        except (RuntimeError, TypeError, AttributeError) as e:
            # C++对象已被Qt删除或无效
            print(f"阴影效果对象无效: {e}")
            return None

        try:
            return self.animate(
                effect,
                "blurRadius",
                start_blur,
                end_blur,
                duration,
                easing_curve,
                finished_callback,
            )
        except Exception as e:
            print(f"创建阴影模糊动画时出错: {e}")
            return None

    @staticmethod
    def get_easing_curve(curve_type=QEasingCurve.Type.OutCubic):
        """
        获取缓动曲线对象

        参数:
            curve_type (QEasingCurve.Type): 缓动曲线类型

        返回:
            QEasingCurve: 缓动曲线对象
        """
        return QEasingCurve(curve_type)

    @staticmethod
    def cubic_bezier(x1, y1, x2, y2):
        """
        创建自定义三次贝塞尔曲线

        参数:
            x1, y1: 第一个控制点
            x2, y2: 第二个控制点

        返回:
            QEasingCurve: 自定义缓动曲线
        """
        curve = QEasingCurve(QEasingCurve.Type.BezierSpline)
        curve.addCubicBezierSegment(
            QPoint(0, 0), QPoint(x1, y1), QPoint(x2, y2), QPoint(1, 1)
        )
        return curve
