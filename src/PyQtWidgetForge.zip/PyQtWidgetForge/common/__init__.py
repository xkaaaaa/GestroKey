"""
PyQtWidgetForge 通用组件模块

此模块包含所有组件可共用的通用类、特效、元素和动画
"""

# 导入子模块
from . import animations, effects, elements

# 导出公共API
__all__ = [
    "effects",
    "elements",
    "animations",
]
