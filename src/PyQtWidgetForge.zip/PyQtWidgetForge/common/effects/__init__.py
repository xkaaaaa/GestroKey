"""
PyQtWidgetForge 通用特效模块

此模块包含可用于各种组件的视觉特效
"""

from enum import Enum

from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import QGraphicsDropShadowEffect

from .glow import AnimatedGlowEffect
from .shadow import AnimatedShadowEffect


# 阴影类型枚举
class ShadowType(Enum):
    """阴影类型枚举"""

    SMALL = 1  # 小阴影
    MEDIUM = 2  # 中阴影
    LARGE = 3  # 大阴影
    EXTRA_LARGE = 4  # 特大阴影


def set_shadow(
    widget, shadow_type=None, blur_radius=None, x_offset=None, y_offset=None, color=None
):
    """
    为控件设置阴影效果

    参数:
        widget: 要设置阴影的控件
        shadow_type: 阴影类型，可以是ShadowType枚举值，或直接指定blur_radius等参数
        blur_radius: 阴影模糊半径
        x_offset: 阴影水平偏移
        y_offset: 阴影垂直偏移
        color: 阴影颜色

    返回:
        QGraphicsDropShadowEffect: 创建的阴影效果对象
    """
    # 创建阴影效果
    shadow = QGraphicsDropShadowEffect(widget)

    # 如果指定了阴影类型
    if shadow_type is not None and isinstance(shadow_type, ShadowType):
        if shadow_type == ShadowType.SMALL:
            shadow.setBlurRadius(5)
            shadow.setOffset(1, 1)
            shadow.setColor(QColor(0, 0, 0, 60))
        elif shadow_type == ShadowType.MEDIUM:
            shadow.setBlurRadius(10)
            shadow.setOffset(3, 3)
            shadow.setColor(QColor(0, 0, 0, 80))
        elif shadow_type == ShadowType.LARGE:
            shadow.setBlurRadius(15)
            shadow.setOffset(5, 5)
            shadow.setColor(QColor(0, 0, 0, 100))
        elif shadow_type == ShadowType.EXTRA_LARGE:
            shadow.setBlurRadius(25)
            shadow.setOffset(8, 8)
            shadow.setColor(QColor(0, 0, 0, 120))

    # 如果直接指定了参数，优先使用指定的参数
    if blur_radius is not None:
        shadow.setBlurRadius(blur_radius)

    if x_offset is not None and y_offset is not None:
        shadow.setOffset(x_offset, y_offset)
    elif y_offset is not None:
        shadow.setOffset(0, y_offset)
    elif x_offset is not None:
        shadow.setOffset(x_offset, 0)

    if color is not None:
        shadow.setColor(color)

    # 应用阴影
    widget.setGraphicsEffect(shadow)

    return shadow


# 导出公共API
__all__ = [
    "AnimatedShadowEffect",
    "AnimatedGlowEffect",
    "ShadowType",
    "set_shadow",
]
