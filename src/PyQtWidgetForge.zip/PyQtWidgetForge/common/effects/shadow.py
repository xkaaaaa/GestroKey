"""
阴影效果模块

提供可动画化的阴影效果，用于为控件添加可交互的阴影
"""
from PyQt6.QtCore import QObject, QPoint, QPointF, Qt, pyqtProperty
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import QGraphicsDropShadowEffect, QWidget

from ..animations import SmoothTransition
from ...widgets.window.theme import ThemeManager


class AnimatedShadowEffect(QObject):
    """
    可动画化的阴影效果

    为控件提供可以通过动画方式改变的阴影效果
    """

    def __init__(self, widget, parent=None):
        """
        初始化阴影效果

        参数:
            widget (QWidget): 要应用阴影的控件
            parent (QObject): 父对象
        """
        # 确保parent参数正确
        if parent is None:
            parent = widget

        super().__init__(parent)

        # 保存目标控件
        self._widget = widget

        # 创建阴影效果
        self._shadow = QGraphicsDropShadowEffect(self)  # 设置为当前对象的子对象，而不是widget的子对象
        self._shadow.setBlurRadius(6)
        self._shadow.setColor(QColor(0, 0, 0, 40))
        self._shadow.setOffset(0, 2)
        self._widget.setGraphicsEffect(self._shadow)

        # 创建动画管理器
        self._transition = SmoothTransition(self)

        self._build_states_by_theme()

        # 监听主题变化
        ThemeManager.instance().theme_changed.connect(self._on_theme_changed)

        # 当前状态
        self._current_state = "normal"

        # 当前参数
        self._current_offset = self._states["normal"]["offset"]
        self._current_blur_radius = self._states["normal"]["blur_radius"]
        self._current_color = self._states["normal"]["color"]

        # 动画持续时间（毫秒）
        self._animation_duration = 150

        # 当控件被销毁时，确保清理资源
        self._widget.destroyed.connect(self._cleanup)

    def _cleanup(self):
        """清理资源"""
        # 停止所有动画
        self._transition.stop_all()
        # 移除与控件的连接
        self._widget = None
        # 断开 ThemeManager 信号，防止销毁后仍触发回调
        try:
            ThemeManager.instance().theme_changed.disconnect(self._on_theme_changed)
        except Exception:
            pass
        # 允许阴影效果被销毁
        if self._shadow:
            try:
                # 检查C++对象是否仍然有效
                self._shadow.isEnabled()
                self._shadow.setParent(None)
            except RuntimeError:
                # C++对象已被删除，无需操作
                pass
            self._shadow = None

    def set_custom_state(self, state_name, offset, blur_radius, color):
        """
        设置自定义状态

        参数:
            state_name (str): 状态名称
            offset (float): 阴影偏移
            blur_radius (float): 阴影模糊半径
            color (QColor): 阴影颜色
        """
        self._states[state_name] = {
            "offset": offset,
            "blur_radius": blur_radius,
            "color": color,
        }

    def set_animation_duration(self, duration):
        """
        设置动画持续时间

        参数:
            duration (int): 动画持续时间，单位毫秒
        """
        self._animation_duration = duration

    def set_state(self, state_name, animate=True):
        """
        设置阴影状态

        参数:
            state_name (str): 状态名称，可以是预定义的"normal"、"hover"、"pressed"、"disabled"或自定义状态
            animate (bool): 是否使用动画过渡，默认为True
        """
        # 检查阴影效果是否有效
        if not self._shadow or not self._widget:
            return

        # 检查状态是否存在
        if state_name not in self._states:
            print(f"警告: 状态'{state_name}'不存在, 使用'normal'状态")
            state_name = "normal"

        # 获取目标状态参数
        target_state = self._states[state_name]
        target_offset = target_state["offset"]
        target_blur_radius = target_state["blur_radius"]
        target_color = target_state["color"]

        try:
            # 如果使用动画
            if animate:
                # 停止所有正在进行的动画
                self._transition.stop_all()

                # 阴影偏移动画
                self._transition.shadow_offset_change(
                    self._shadow,
                    self._current_offset,
                    target_offset,
                    self._animation_duration,
                )

                # 阴影模糊半径动画
                self._transition.shadow_blur_change(
                    self._shadow,
                    self._current_blur_radius,
                    target_blur_radius,
                    self._animation_duration,
                )

                # 阴影颜色动画
                self._transition.color_change(
                    self._shadow,
                    "color",
                    self._current_color,
                    target_color,
                    self._animation_duration,
                )
            else:
                # 直接设置属性
                self._shadow.setOffset(0, target_offset)
                self._shadow.setBlurRadius(target_blur_radius)
                self._shadow.setColor(target_color)
        except RuntimeError:
            # 底层 C++ 对象已被删除
            return

        # 更新当前值
        self._current_offset = target_offset
        self._current_blur_radius = target_blur_radius
        self._current_color = target_color
        self._current_state = state_name

    def get_current_state(self):
        """
        获取当前状态名称

        返回:
            str: 当前状态名称
        """
        return self._current_state

    def stop_animations(self):
        """停止所有动画"""
        self._transition.stop_all()

    def _build_states_by_theme(self):
        """根据当前主题重新生成阴影状态表"""
        is_dark = ThemeManager.instance().is_dark_mode()

        if is_dark:
            # 深色背景：提高透明度以增强可见度
            base_color = {
                "normal": QColor(255, 255, 255, 60),   # 原25 → 60
                "hover": QColor(255, 255, 255, 90),   # 原35 → 90
                "pressed": QColor(255, 255, 255, 110), # 原45 → 110
                "disabled": QColor(255, 255, 255, 40), # 原15 → 40
            }
            blur_normal = 8.0
            blur_hover = 12.0
            blur_pressed = 6.0
            offset_normal = 3.0
            offset_hover = 4.0
            offset_pressed = 2.0
        else:
            # 浅色背景保持原逻辑
            base_color = {
                "normal": QColor(0, 0, 0, 40),
                "hover": QColor(0, 0, 0, 55),
                "pressed": QColor(0, 0, 0, 70),
                "disabled": QColor(0, 0, 0, 25),
            }
            blur_normal = 6.0
            blur_hover = 8.0
            blur_pressed = 4.0
            offset_normal = 2.0
            offset_hover = 3.0
            offset_pressed = 1.0

        self._states = {
            "normal": {"offset": offset_normal, "blur_radius": blur_normal, "color": base_color["normal"]},
            "hover": {"offset": offset_hover, "blur_radius": blur_hover, "color": base_color["hover"]},
            "pressed": {"offset": offset_pressed, "blur_radius": blur_pressed, "color": base_color["pressed"]},
            "disabled": {"offset": offset_pressed, "blur_radius": blur_pressed, "color": base_color["disabled"]},
        }

    def _on_theme_changed(self):
        """主题变更后更新阴影颜色"""
        # 若阴影已经被销毁则跳过
        if self._shadow is None:
            return
        prev_state = self._current_state
        self._build_states_by_theme()
        # 立即应用当前状态颜色（无动画）
        self.set_state(prev_state, animate=False)
