"""
辉光效果模块

提供可动画化的辉光效果，用于为控件添加可交互的发光效果
"""
from PyQt6.QtCore import QObject, Qt, pyqtProperty
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import QGraphicsDropShadowEffect, QWidget

from ..animations import SmoothTransition


class AnimatedGlowEffect(QObject):
    """
    可动画化的辉光效果

    为控件提供可以通过动画方式改变的辉光效果，使用四周发光效果来突出控件
    """

    def __init__(self, widget, parent=None, glow_color=QColor(61, 174, 233)):
        """
        初始化辉光效果

        参数:
            widget (QWidget): 要应用辉光的控件
            parent (QObject): 父对象
            glow_color (QColor): 辉光颜色，默认为蓝色
        """
        super().__init__(parent)

        # 保存目标控件
        self._widget = widget

        # 创建辉光效果 - 使用QGraphicsDropShadowEffect实现
        self._glow = QGraphicsDropShadowEffect(widget)
        self._glow.setOffset(0, 0)  # 让辉光居中，四周都有发光效果
        self._glow.setBlurRadius(15)  # 默认模糊半径
        self._glow.setColor(glow_color.lighter(120))  # 使用稍亮的颜色
        self._widget.setGraphicsEffect(self._glow)

        # 创建动画管理器
        self._transition = SmoothTransition(self)

        # 保存辉光颜色
        self._glow_color = glow_color

        # 当前辉光参数
        self._current_strength = 0.3  # 默认就有微弱辉光强度
        self._current_blur_radius = 12  # 默认模糊半径

        # 辉光状态参数
        self._states = {
            "normal": {"strength": 0.3, "blur_radius": 12},  # 正常状态辉光强度  # 正常状态模糊半径
            "hover": {"strength": 0.7, "blur_radius": 18},  # 悬停状态辉光强度  # 悬停状态模糊半径
            "pressed": {"strength": 1.0, "blur_radius": 22},  # 按下状态辉光强度  # 按下状态模糊半径
            "disabled": {"strength": 0.15, "blur_radius": 8},  # 禁用状态辉光强度  # 禁用状态模糊半径
        }

        # 当前状态
        self._current_state = "normal"

        # 动画持续时间（毫秒）
        self._animation_duration = 300

        # 初始化辉光效果
        self._update_glow_effect()

    def set_custom_state(self, state_name, strength, blur_radius):
        """
        设置自定义状态

        参数:
            state_name (str): 状态名称
            strength (float): 辉光强度，范围从0.0到1.0
            blur_radius (float): 辉光模糊半径
        """
        self._states[state_name] = {"strength": strength, "blur_radius": blur_radius}

    def set_animation_duration(self, duration):
        """
        设置动画持续时间

        参数:
            duration (int): 动画持续时间，单位毫秒
        """
        self._animation_duration = duration

    def set_state(self, state_name, animate=True):
        """
        设置辉光状态

        参数:
            state_name (str): 状态名称，可以是预定义的"normal"、"hover"、"pressed"、"disabled"或自定义状态
            animate (bool): 是否使用动画过渡，默认为True
        """
        try:
            # 检查状态是否存在
            if state_name not in self._states:
                print(f"警告: 状态'{state_name}'不存在, 使用'normal'状态")
                state_name = "normal"

            # 获取目标状态参数
            target_state = self._states[state_name]
            target_strength = target_state["strength"]
            target_blur_radius = target_state["blur_radius"]

            # 如果使用动画
            if animate:
                try:
                    # 停止所有正在进行的动画
                    self._transition.stop_all()

                    # 辉光强度动画
                    self._transition.animate(
                        self,
                        "strength",
                        self._current_strength,
                        target_strength,
                        self._animation_duration,
                    )

                    # 检查glow是否有效
                    if self._glow:
                        # 辉光模糊半径动画
                        self._transition.shadow_blur_change(
                            self._glow,
                            self._current_blur_radius,
                            target_blur_radius,
                            self._animation_duration,
                        )
                except Exception as e:
                    print(f"设置状态动画时出错: {e}")
                    # 在动画失败的情况下直接设置属性
                    self.strength = target_strength
                    if self._glow:
                        try:
                            self._glow.setBlurRadius(target_blur_radius)
                        except:
                            pass
            else:
                # 直接设置属性
                self.strength = target_strength
                if self._glow:
                    try:
                        self._glow.setBlurRadius(target_blur_radius)
                    except Exception as e:
                        print(f"设置模糊半径时出错: {e}")

            # 更新当前值
            self._current_strength = target_strength
            self._current_blur_radius = target_blur_radius
            self._current_state = state_name
        except Exception as e:
            print(f"设置辉光状态时出错: {e}")

    def _update_glow_effect(self):
        """更新辉光效果"""
        # 用更加安全的方式检查widget和glow是否有效
        try:
            # 首先检查widget是否存在且有效
            if not self._widget:
                return

            # 尝试安全获取当前的图形效果
            current_effect = None
            try:
                current_effect = self._widget.graphicsEffect()
            except (RuntimeError, TypeError, AttributeError) as e:
                # 控件可能已被删除或无效
                print(f"获取graphicsEffect时出错: {e}")
                return

            # 如果当前效果不是我们的glow效果，需要重新创建
            if not self._glow or current_effect != self._glow:
                try:
                    # 尝试创建新的辉光效果
                    self._glow = QGraphicsDropShadowEffect(self._widget)
                    self._glow.setOffset(0, 0)
                    self._glow.setBlurRadius(self._current_blur_radius)

                    # 设置新的辉光效果
                    self._widget.setGraphicsEffect(self._glow)
                except Exception as e:
                    print(f"创建新的辉光效果时出错: {e}")
                    return

            # 根据辉光强度调整阴影颜色
            glow_color = QColor(self._glow_color)
            glow_color.setAlphaF(0.6 * self._current_strength)  # 调整透明度

            # 更新辉光效果
            try:
                self._glow.setColor(glow_color)
                self._glow.setBlurRadius(self._current_blur_radius)
            except Exception as e:
                print(f"更新辉光效果时出错: {e}")
        except Exception as e:
            # 捕获任何其他可能的异常
            print(f"辉光效果更新时发生未知错误: {e}")

    def set_glow_color(self, color):
        """
        设置辉光颜色

        参数:
            color (QColor): 辉光颜色
        """
        if self._glow_color != color:
            self._glow_color = color
            self._update_glow_effect()

    def get_glow_color(self):
        """
        获取当前辉光颜色

        返回:
            QColor: 当前辉光颜色
        """
        return self._glow_color

    def get_current_state(self):
        """
        获取当前状态名称

        返回:
            str: 当前状态名称
        """
        return self._current_state

    def stop_animations(self):
        """停止所有动画"""
        self._transition.stop_all()

    # 属性定义，使其可以被动画引擎使用
    @pyqtProperty(float)
    def strength(self):
        """获取辉光强度"""
        return self._current_strength

    @strength.setter
    def strength(self, strength):
        """设置辉光强度并更新辉光效果"""
        if self._current_strength != strength:
            self._current_strength = strength
            try:
                self._update_glow_effect()
            except Exception as e:
                print(f"更新辉光强度时出错: {e}")

    @pyqtProperty(float)
    def blurRadius(self):
        """获取辉光模糊半径"""
        return self._current_blur_radius

    @blurRadius.setter
    def blurRadius(self, radius):
        """设置辉光模糊半径并更新"""
        if self._current_blur_radius != radius:
            self._current_blur_radius = radius
            try:
                self._update_glow_effect()
            except Exception as e:
                print(f"更新模糊半径时出错: {e}")
