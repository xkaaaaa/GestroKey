"""
PyQtWidgetForge 通用元素模块

此模块包含可用于多个组件的基础UI元素
"""
from .menu import RoundMenu

# 导出公共API
__all__ = ["RoundMenu"]
