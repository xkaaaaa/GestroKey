"""
圆角菜单元素模块

提供可以应用于多种组件的圆角菜单元素，支持多级菜单
"""
from enum import Enum
from pathlib import Path

from PyQt6.QtCore import (
    QEasingCurve,
    QEvent,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    QSize,
    Qt,
)
from PyQt6.QtGui import (
    QAction,
    QBitmap,
    QColor,
    QCursor,
    QIcon,
    QPainter,
    QPainterPath,
    QPalette,
    QPen,
    QRegion,
    QScreen,
)
from PyQt6.QtWidgets import QApplication, QMenu, QWidget

# 导入自定义模块
from ...utils.icon import get_icon
from ...widgets.window.theme import ThemeManager


class PopupPosition(Enum):
    """
    菜单弹出位置枚举

    定义了菜单可以弹出的各种位置选项
    """

    AUTO = 0  # 自动选择最佳位置
    CURSOR = 1  # 鼠标光标位置
    CENTER = 2  # 在目标控件中心位置
    TOP_LEFT = 3  # 控件的左上角
    TOP = 4  # 控件的顶部中心
    TOP_RIGHT = 5  # 控件的右上角
    RIGHT = 6  # 控件的右侧中心
    BOTTOM_RIGHT = 7  # 控件的右下角
    BOTTOM = 8  # 控件的底部中心
    BOTTOM_LEFT = 9  # 控件的左下角
    LEFT = 10  # 控件的左侧中心


class AlignPoint(Enum):
    """
    菜单对齐点枚举

    定义了菜单的哪个点应该与目标位置对齐
    """

    TOP_LEFT = 0  # 菜单的左上角
    TOP = 1  # 菜单的顶部中心
    TOP_RIGHT = 2  # 菜单的右上角
    RIGHT = 3  # 菜单的右侧中心
    BOTTOM_RIGHT = 4  # 菜单的右下角
    BOTTOM = 5  # 菜单的底部中心
    BOTTOM_LEFT = 6  # 菜单的左下角
    LEFT = 7  # 菜单的左侧中心
    CENTER = 8  # 菜单的中心


class RoundMenu(QMenu):
    """
    圆角菜单

    提供带有圆角边框和动画效果的美观菜单，
    可用于下拉按钮、右键菜单等场景，
    支持多级子菜单
    """

    def __init__(self, title=None, parent=None, radius=8, bg_color: str | None = None):
        """
        初始化圆角菜单

        参数:
            title (str, optional): 菜单标题
            parent (QWidget, optional): 父级组件
            radius (int): 圆角半径
            bg_color (str | None): 背景颜色。如果为 None，则使用 ThemeManager 的当前主题色。
                                其他颜色将根据背景色自动计算。
        """
        if title is None:
            super().__init__(parent)
        else:
            super().__init__(title, parent)

        # 设置圆角半径
        self._radius = radius

        # 主题配色
        if bg_color is None:
            self._bg_color = ThemeManager.instance().get_theme_color().name()
        else:
            self._bg_color = bg_color

        # 边框宽度
        self._border_width = 1

        # 设置属性 - 完全透明背景以支持真正的圆角
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.NoDropShadowWindowHint)

        # 动画效果设置
        self._opacity = 0.0
        self._animation = QPropertyAnimation(self, b"windowOpacity")
        self._animation.setDuration(150)  # 150毫秒的动画持续时间
        self._animation.setStartValue(0.0)
        self._animation.setEndValue(1.0)
        self._animation.setEasingCurve(QEasingCurve.Type.OutQuad)

        # 子菜单显示延迟
        self.setStyle(self.style())  # 使用当前样式

        # 根据背景色自动计算其他颜色
        self._auto_adjust_colors()

        # 设置菜单样式
        self._init_style()

        # 安装事件过滤器
        self.installEventFilter(self)

        # 连接到主题变化信号
        ThemeManager.instance().theme_changed.connect(self._on_theme_changed)

    def _on_theme_changed(self):
        """当主题颜色变化时，更新菜单颜色。"""
        new_theme_color = ThemeManager.instance().get_theme_color().name()
        self.set_colors(bg_color=new_theme_color)

    def _is_dark_color(self, color_str):
        """
        判断颜色是否为深色

        参数:
            color_str (str): 十六进制颜色字符串，如 "#RRGGBB"

        返回:
            bool: 如果是深色则返回True，否则返回False
        """
        # 转换为QColor以便于处理
        color = QColor(color_str)

        # 计算亮度 (基于人类感知的加权RGB值)
        # 公式: 0.299*R + 0.587*G + 0.114*B
        luminance = (
            0.299 * color.red() + 0.587 * color.green() + 0.114 * color.blue()
        ) / 255.0

        # 亮度小于0.5认为是深色
        return luminance < 0.5

    def _get_contrast_color(self, bg_color, alpha=1.0):
        """
        根据背景色获取对比色

        参数:
            bg_color (str): 背景色十六进制字符串
            alpha (float): 透明度，0.0到1.0之间

        返回:
            str: 对比色的十六进制字符串
        """
        is_dark = self._is_dark_color(bg_color)

        if is_dark:
            # 深色背景，使用浅色前景
            r, g, b = 255, 255, 255
        else:
            # 浅色背景，使用深色前景
            r, g, b = 50, 50, 50

        # 创建带透明度的颜色
        color = QColor(r, g, b, int(alpha * 255))
        return color.name(QColor.NameFormat.HexArgb)

    def _get_semi_transparent_color(self, base_color, alpha=0.7):
        """
        获取半透明版本的颜色

        参数:
            base_color (str): 基础颜色十六进制字符串
            alpha (float): 透明度，0.0到1.0之间

        返回:
            str: 半透明颜色的十六进制字符串
        """
        color = QColor(base_color)
        color.setAlphaF(alpha)
        return color.name(QColor.NameFormat.HexArgb)

    def _auto_adjust_colors(self):
        """
        根据背景色自动调整其他颜色
        """
        # 判断背景是否为深色
        is_dark_bg = self._is_dark_color(self._bg_color)

        # 设置文本颜色，深色背景用浅色文本，浅色背景用深色文本
        self._text_color = "#ffffff" if is_dark_bg else "#333333"

        # 设置边框颜色，稍微比文本颜色透明
        text_color = QColor(self._text_color)
        if is_dark_bg:
            # 深色背景的边框稍暗一些
            border_alpha = 0.3
        else:
            # 浅色背景的边框稍亮一些
            border_alpha = 0.2

        # 创建边框颜色
        border_color = QColor(text_color)
        border_color.setAlphaF(border_alpha)
        self._border_color = border_color.name(QColor.NameFormat.HexArgb)

        # 设置分隔线颜色
        separator_color = QColor(text_color)
        separator_color.setAlphaF(0.2)  # 比边框更透明
        self._separator_color = separator_color.name(QColor.NameFormat.HexArgb)

        # 设置禁用项的颜色
        disabled_color = QColor(text_color)
        disabled_color.setAlphaF(0.4)  # 半透明
        self._disabled_color = disabled_color.name(QColor.NameFormat.HexArgb)

        # 设置高亮背景色
        if is_dark_bg:
            # 深色背景下，高亮色比背景亮一些
            bg_color = QColor(self._bg_color)
            highlight = QColor(
                min(bg_color.red() + 50, 255),
                min(bg_color.green() + 50, 255),
                min(bg_color.blue() + 50, 255),
            )
            self._highlight_color = highlight.name()
        else:
            # 浅色背景下，高亮色比背景暗一些
            bg_color = QColor(self._bg_color)
            highlight = QColor(
                max(bg_color.red() - 15, 0),
                max(bg_color.green() - 15, 0),
                max(bg_color.blue() - 15, 0),
            )
            self._highlight_color = highlight.name()

        # 更新子菜单箭头图标
        icon_color = self._text_color
        self._submenu_arrow_icon = get_icon(
            "chevron-right", color=icon_color, size=QSize(12, 12)
        )

    def _init_style(self):
        """初始化菜单样式"""
        # 设置子菜单延迟时间（毫秒）
        self.setObjectName("RoundMenu")
        self.setMouseTracking(True)

        # 根据背景色自动调整其他颜色
        self._auto_adjust_colors()

        # 设置子菜单箭头图标
        self._submenu_arrow_icon = get_icon(
            "chevron-right", color=self._text_color, size=QSize(12, 12)
        )

        # 应用基本样式 - 设置完全透明背景
        self.setStyleSheet(
            f"""
            QMenu {{
                background-color: transparent;
                border: none;
                padding: 5px;
            }}
            QMenu::item {{
                background-color: transparent;
                padding: 8px 12px 8px 12px;
                border-radius: {max(self._radius - 3, 3)}px;
                margin: 2px;
                color: {self._text_color};
                font-size: 14px;
            }}
            QMenu::item:selected {{
                background-color: {self._highlight_color};
            }}
            QMenu::separator {{
                height: 1px;
                background-color: {self._separator_color};
                margin: 5px 5px;
            }}
            QMenu::item:disabled {{
                color: {self._disabled_color};
            }}
            QMenu::indicator {{
                width: 18px;
                height: 18px;
                padding-left: 6px;
            }}
            QMenu::icon {{
                padding-left: 8px;
                padding-right: 4px;
            }}
            /* 隐藏右侧箭头 */
            QMenu::right-arrow {{
                width: 0px;
                height: 0px;
                margin: 0px;
            }}
        """
        )

    def eventFilter(self, obj, event):
        """事件过滤器，用于处理菜单显示和子菜单位置调整"""
        if event.type() == QEvent.Type.Show and obj == self:
            # 播放显示动画
            self._animation.start()

            # 检查菜单位置是否超出屏幕边界，如果是则调整位置
            if self.isVisible():
                self._adjust_menu_position()

            # 菜单显示后应用窗口形状
            self._update_window_shape()

        elif event.type() == QEvent.Type.Resize and obj == self:
            # 大小改变时更新窗口形状
            self._update_window_shape()

        return super().eventFilter(obj, event)

    def _update_window_shape(self):
        """更新窗口形状为圆角矩形"""
        # 如果尺寸无效，不更新形状
        if self.width() <= 0 or self.height() <= 0:
            return

        # 创建位图，用于设置窗口形状
        bitmap = QBitmap(self.size())
        bitmap.fill(Qt.GlobalColor.color0)  # 填充透明

        # 创建画家
        painter = QPainter(bitmap)
        # 必须启用抗锯齿以获得平滑的圆角
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        # 填充圆角矩形
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(Qt.GlobalColor.color1)  # 填充不透明

        # 创建圆角矩形路径
        path = QPainterPath()
        path.addRoundedRect(
            0,  # 使用0, 0作为起点
            0,
            self.width(),  # 使用宽高而不是rect()
            self.height(),
            self._radius,
            self._radius,
        )

        # 绘制路径
        painter.drawPath(path)
        painter.end()

        # 应用形状
        self.setMask(bitmap)

    def _adjust_menu_position(self):
        """调整菜单位置，确保不超出屏幕边界"""
        screen = QApplication.screenAt(self.mapToGlobal(QPoint(0, 0)))
        if not screen:
            screen = QApplication.primaryScreen()

        screen_geometry = screen.availableGeometry()
        menu_geometry = self.geometry()
        menu_global_pos = self.mapToGlobal(QPoint(0, 0))

        # 创建菜单在全局坐标系中的几何区域
        global_menu_geometry = QRect(menu_global_pos, menu_geometry.size())

        # 检查右边界
        if global_menu_geometry.right() > screen_geometry.right():
            x_offset = global_menu_geometry.right() - screen_geometry.right()
            new_x = menu_global_pos.x() - x_offset
            # 如果是子菜单，则可能需要显示在父菜单的左侧
            if self.parent() and isinstance(self.parent(), QMenu):
                parent_global_pos = self.parent().mapToGlobal(QPoint(0, 0))
                if new_x < parent_global_pos.x():
                    # 显示在父菜单的左侧
                    new_x = parent_global_pos.x() - menu_geometry.width()
            self.move(new_x, menu_global_pos.y())

        # 检查底部边界
        if global_menu_geometry.bottom() > screen_geometry.bottom():
            y_offset = global_menu_geometry.bottom() - screen_geometry.bottom()
            new_y = menu_global_pos.y() - y_offset
            self.move(menu_global_pos.x(), new_y)

    def paintEvent(self, event):
        """重写绘制事件，实现圆角菜单"""
        # 创建画家
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        # 获取绘制区域
        rect = self.rect()

        # 创建圆角矩形路径 - 与窗口形状完全相同的参数
        path = QPainterPath()
        path.addRoundedRect(
            0, 0, self.width(), self.height(), self._radius, self._radius
        )

        # 绘制背景 - 使用填充路径，这样不会有边缘锯齿
        bg_color = QColor(self._bg_color)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(bg_color)
        painter.drawPath(path)

        # 绘制边框 - 使用路径描边
        if self._border_width > 0:
            # 为边框创建合适的路径
            border_path = QPainterPath()
            # 计算边框路径的尺寸 - 考虑边框宽度
            border_inset = self._border_width / 2.0
            border_width = self.width() - self._border_width
            border_height = self.height() - self._border_width

            # 根据边框宽度适当减小圆角半径
            border_radius = max(self._radius - border_inset, 0)

            border_path.addRoundedRect(
                border_inset,
                border_inset,
                border_width,
                border_height,
                border_radius,
                border_radius,
            )

            border_color = QColor(self._border_color)
            pen = QPen(border_color)
            pen.setWidth(self._border_width)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawPath(border_path)

        # 设置裁剪区域，确保子控件不超出圆角区域
        painter.setClipPath(path)

        # 用完全透明的方式调用父类绘制，保留菜单内容
        super().paintEvent(event)

    def showEvent(self, event):
        """菜单显示事件"""
        super().showEvent(event)
        # 更新窗口形状
        self._update_window_shape()
        self._animation.start()

    def resizeEvent(self, event):
        """大小变化事件"""
        super().resizeEvent(event)
        # 更新窗口形状
        self._update_window_shape()

    def set_radius(self, radius):
        """
        设置圆角半径

        参数:
            radius (int): 圆角半径
        """
        self._radius = radius
        self._init_style()  # 更新样式
        self._update_window_shape()  # 更新窗口形状
        self.update()

    def get_radius(self):
        """
        获取圆角半径

        返回:
            int: 圆角半径
        """
        return self._radius

    def set_border_width(self, width):
        """
        设置边框宽度

        参数:
            width (int): 边框宽度
        """
        self._border_width = width
        self.update()

    def get_border_width(self):
        """
        获取边框宽度

        返回:
            int: 边框宽度
        """
        return self._border_width

    def set_colors(self, bg_color=None):
        """
        设置菜单颜色

        参数:
            bg_color (str): 背景颜色，其他颜色将根据背景色自动计算
        """
        if bg_color:
            self._bg_color = bg_color
            # 根据背景色自动调整其他颜色
            self._auto_adjust_colors()
        else:
            # 如果 bg_color 为 None，则不应改变当前颜色，除非是主题同步的特定调用
            # _init_style() 应该总是基于当前的 self._bg_color
            self._init_style()
        self.update()

    def get_colors(self):
        """
        获取当前菜单颜色

        返回:
            dict: 包含所有颜色的字典
        """
        return {
            "bg_color": self._bg_color,
            "border_color": self._border_color,
            "text_color": self._text_color,
            "highlight_color": self._highlight_color,
            "separator_color": self._separator_color,
            "disabled_color": self._disabled_color,
        }

    def addMenu(self, menu_or_title):
        """
        添加子菜单，支持传入菜单对象或标题字符串

        参数:
            menu_or_title: 菜单对象(QMenu)或菜单标题(str)

        返回:
            QMenu: 创建的子菜单对象
        """
        # 如果传入标题字符串，创建新的RoundMenu
        if isinstance(menu_or_title, str):
            # 创建子菜单时，继承父菜单的背景色和圆角半径
            submenu = RoundMenu(
                menu_or_title, self, self._radius
            )
            submenu.set_border_width(self._border_width)
            action = super().addMenu(submenu)
            self._setup_submenu_action(action)
            return submenu
        # 如果传入的已经是菜单对象但不是RoundMenu类型
        elif not isinstance(menu_or_title, RoundMenu):
            # 创建一个新的RoundMenu并复制原菜单的内容
            title = menu_or_title.title()
            # 创建子菜单时，继承父菜单的背景色和圆角半径
            submenu = RoundMenu(title, self, self._radius)
            submenu.set_border_width(self._border_width)

            # 复制原菜单中的所有动作
            for action in menu_or_title.actions():
                submenu.addAction(action)

            action = super().addMenu(submenu)
            self._setup_submenu_action(action)
            return submenu
        # 如果传入的已经是RoundMenu类型
        else:
            # 同步菜单颜色 - 子菜单现在应该自己处理主题同步
            menu_or_title.set_border_width(self._border_width)
            action = super().addMenu(menu_or_title)
            self._setup_submenu_action(action)
            return menu_or_title

    def _setup_submenu_action(self, action):
        """设置子菜单动作的样式和图标"""
        # 设置子菜单图标为箭头
        if action.icon().isNull():
            action.setIcon(self._submenu_arrow_icon)

    def addAction(self, action_or_text, slot=None):
        """
        添加动作，支持传入动作对象或文本

        参数:
            action_or_text: 动作对象(QAction)或动作文本(str)
            slot: 点击时触发的槽函数

        返回:
            QAction: 创建的动作对象
        """
        # 如果传入文本，创建新的QAction
        if isinstance(action_or_text, str):
            action = QAction(action_or_text, self)
            if slot is not None:
                action.triggered.connect(slot)
            return super().addAction(action)
        # 如果传入的已经是动作对象
        else:
            return super().addAction(action_or_text)

    def addSeparator(self):
        """添加分隔线"""
        return super().addSeparator()

    def popup(
        self,
        position,
        action=None,
        target_widget=None,
        pos_type=PopupPosition.AUTO,
        align_point=AlignPoint.TOP_LEFT,
    ):
        """
        在指定位置弹出菜单

        参数:
            position (QPoint): 弹出位置
            action (QAction, optional): 初始焦点的动作
            target_widget (QWidget, optional): 目标控件，用于相对定位
            pos_type (PopupPosition): 弹出位置类型
            align_point (AlignPoint): 菜单对齐点
        """
        # 设置不透明度为0，准备执行动画
        self.setWindowOpacity(0.0)

        # 如果指定了目标控件和位置类型，则计算实际显示位置
        if target_widget and pos_type != PopupPosition.CURSOR:
            final_pos = self._calculate_position(target_widget, pos_type, align_point)
            super().popup(final_pos, action)
        elif pos_type == PopupPosition.CURSOR:
            # 如果是鼠标指针位置，直接使用当前鼠标位置
            cursor_pos = QCursor.pos()
            # 根据对齐点调整位置
            adjusted_pos = self._adjust_for_align_point(cursor_pos, align_point)
            super().popup(adjusted_pos, action)
        else:
            # 根据对齐点调整位置
            adjusted_pos = self._adjust_for_align_point(position, align_point)
            super().popup(adjusted_pos, action)

    def exec(
        self,
        position=None,
        target_widget=None,
        pos_type=PopupPosition.AUTO,
        align_point=AlignPoint.TOP_LEFT,
    ):
        """
        执行菜单并返回选中的动作

        参数:
            position (QPoint, optional): 弹出位置，如果不指定且没有指定目标控件，则使用光标位置
            target_widget (QWidget, optional): 目标控件，用于相对定位
            pos_type (PopupPosition): 弹出位置类型
            align_point (AlignPoint): 菜单对齐点

        返回:
            QAction: 选中的动作
        """
        # 设置不透明度为0，准备执行动画
        self.setWindowOpacity(0.0)

        # 如果指定了目标控件和位置类型，则计算实际显示位置
        if target_widget and pos_type != PopupPosition.CURSOR:
            final_pos = self._calculate_position(target_widget, pos_type, align_point)
            return super().exec(final_pos)
        elif pos_type == PopupPosition.CURSOR:
            # 如果是鼠标指针位置，直接使用当前鼠标位置
            cursor_pos = QCursor.pos()
            # 根据对齐点调整位置
            adjusted_pos = self._adjust_for_align_point(cursor_pos, align_point)
            return super().exec(adjusted_pos)
        elif position is not None:
            # 根据对齐点调整位置
            adjusted_pos = self._adjust_for_align_point(position, align_point)
            return super().exec(adjusted_pos)
        else:
            return super().exec()

    def _adjust_for_align_point(self, position, align_point):
        """
        根据对齐点调整菜单位置

        参数:
            position (QPoint): 原始位置
            align_point (AlignPoint): 菜单对齐点

        返回:
            QPoint: 调整后的位置
        """
        # 获取菜单尺寸
        size = self.sizeHint()
        width = size.width()
        height = size.height()

        # 根据对齐点计算偏移量
        if align_point == AlignPoint.TOP_LEFT:
            # 默认是左上角对齐，不需要偏移
            return position
        elif align_point == AlignPoint.TOP:
            return QPoint(position.x() - width // 2, position.y())
        elif align_point == AlignPoint.TOP_RIGHT:
            return QPoint(position.x() - width, position.y())
        elif align_point == AlignPoint.RIGHT:
            return QPoint(position.x() - width, position.y() - height // 2)
        elif align_point == AlignPoint.BOTTOM_RIGHT:
            return QPoint(position.x() - width, position.y() - height)
        elif align_point == AlignPoint.BOTTOM:
            return QPoint(position.x() - width // 2, position.y() - height)
        elif align_point == AlignPoint.BOTTOM_LEFT:
            return QPoint(position.x(), position.y() - height)
        elif align_point == AlignPoint.LEFT:
            return QPoint(position.x(), position.y() - height // 2)
        elif align_point == AlignPoint.CENTER:
            return QPoint(position.x() - width // 2, position.y() - height // 2)
        else:
            return position

    def _calculate_position(self, widget, pos_type, align_point=AlignPoint.TOP_LEFT):
        """
        根据目标控件和位置类型计算菜单显示位置

        参数:
            widget (QWidget): 目标控件
            pos_type (PopupPosition): 位置类型
            align_point (AlignPoint): 菜单对齐点

        返回:
            QPoint: 菜单应该显示的全局坐标
        """
        # 获取控件在全局坐标系中的几何区域
        widget_rect = QRect(widget.mapToGlobal(QPoint(0, 0)), widget.size())

        if pos_type == PopupPosition.AUTO:
            # 自动选择最佳位置（默认为底部中心）
            pos_type = PopupPosition.BOTTOM

            # 检查屏幕空间，如果底部空间不足，则考虑其他位置
            screen = QApplication.screenAt(widget_rect.center())
            if not screen:
                screen = QApplication.primaryScreen()

            screen_geometry = screen.availableGeometry()

            # 估计菜单大小
            menu_size = self.sizeHint()

            # 检查底部空间
            if widget_rect.bottom() + menu_size.height() > screen_geometry.bottom():
                # 底部空间不足，尝试顶部
                if widget_rect.top() - menu_size.height() >= screen_geometry.top():
                    pos_type = PopupPosition.TOP
                else:
                    # 顶部也不够，尝试右侧
                    if (
                        widget_rect.right() + menu_size.width()
                        <= screen_geometry.right()
                    ):
                        pos_type = PopupPosition.RIGHT
                    else:
                        # 右侧也不够，使用左侧
                        pos_type = PopupPosition.LEFT

        # 根据位置类型计算坐标
        if pos_type == PopupPosition.CURSOR:
            position = QCursor.pos()
        elif pos_type == PopupPosition.CENTER:
            position = widget_rect.center()
        elif pos_type == PopupPosition.TOP_LEFT:
            position = widget_rect.topLeft()
        elif pos_type == PopupPosition.TOP:
            position = QPoint(
                widget_rect.left() + widget_rect.width() // 2, widget_rect.top()
            )
        elif pos_type == PopupPosition.TOP_RIGHT:
            position = widget_rect.topRight()
        elif pos_type == PopupPosition.RIGHT:
            position = QPoint(
                widget_rect.right(), widget_rect.top() + widget_rect.height() // 2
            )
        elif pos_type == PopupPosition.BOTTOM_RIGHT:
            position = widget_rect.bottomRight()
        elif pos_type == PopupPosition.BOTTOM:
            position = QPoint(
                widget_rect.left() + widget_rect.width() // 2, widget_rect.bottom()
            )
        elif pos_type == PopupPosition.BOTTOM_LEFT:
            position = widget_rect.bottomLeft()
        elif pos_type == PopupPosition.LEFT:
            position = QPoint(
                widget_rect.left(), widget_rect.top() + widget_rect.height() // 2
            )
        else:
            # 默认使用底部中心
            position = QPoint(
                widget_rect.left() + widget_rect.width() // 2, widget_rect.bottom()
            )

        # 根据对齐点调整位置
        return self._adjust_for_align_point(position, align_point)

    def hideEvent(self, event):
        """菜单隐藏事件"""
        self._animation.stop()
        # 考虑在这里断开 theme_changed 信号，如果菜单不常驻或父级管理不当
        # 但通常Qt的父子关系会自动处理信号槽的生命周期管理，若父级销毁则连接断开
        # 为保持简单，暂时不在这里断开，依赖标准的对象销毁机制。
        # 如果发现问题（例如RoundMenu实例比ThemeManager活得长且未被正确清理），则需要添加断开逻辑。
        # try:
        #     ThemeManager.instance().theme_changed.disconnect(self._on_theme_changed)
        # except TypeError:
        #     pass # Signal not connected or already disconnected
        super().hideEvent(event)

    def setStyleSheet(self, styleSheet):
        """
        设置样式表
        确保样式表中包含圆角半径设置

        参数:
            styleSheet (str): 样式表字符串
        """
        super().setStyleSheet(styleSheet)
