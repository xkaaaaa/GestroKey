from __future__ import annotations

"""
按钮组件示例（重写版）

本示例展示新版 `Button` 组件的基本用法，以及如何通过参数
控制文本、图标与禁用状态。
"""

import sys
from pathlib import Path

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QVBoxLayout,
    QWidget,
    QGroupBox,
    QHBoxLayout,
    QButtonGroup,
    QRadioButton,
)

# 将项目根目录加入路径，确保可以 import PyQtWidgetForge
PROJECT_ROOT = Path(__file__).parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from PyQtWidgetForge.utils.icon import get_icon, list_icons
from PyQtWidgetForge.widgets import ForgeButton, ThemeManager, ThemeMode, Window


class ButtonDemo(Window):
    """按钮组件演示窗口"""

    def __init__(self) -> None:
        super().__init__(title="PyQtWidgetForge 按钮组件演示", width=800, height=600)

        # 中心部件
        central = QWidget()
        self.setCentralWidget(central)
        self.layout = QVBoxLayout(central)

        # 标题
        title = QLabel("Button 演示")
        font = QFont()
        font.setPointSize(16)
        font.setBold(True)
        title.setFont(font)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(title)

        # 预览按钮
        self.preview_button = ForgeButton("演示按钮")
        self.layout.addWidget(self.preview_button, alignment=Qt.AlignmentFlag.AlignCenter)

        # 按钮类型
        self.button_type_combo = QComboBox()
        self.button_type_combo.addItems(["basic", "toggle", "dropdown", "split"])
        self.button_type_combo.currentIndexChanged.connect(self.refresh_button)
        form = QFormLayout()
        self.layout.addLayout(form)
        form.addRow("按钮类型:", self.button_type_combo)

        # 参数面板
        form = QFormLayout()
        self.layout.addLayout(form)

        # 文本
        self.text_edit = QLineEdit("演示按钮")
        self.text_edit.textChanged.connect(self.refresh_button)
        form.addRow("按钮文本:", self.text_edit)

        # 图标
        self.icon_combo = QComboBox()
        self.icon_combo.addItem("无图标", "")
        for name in sorted(list_icons()):
            self.icon_combo.addItem(name, name)
        self.icon_combo.currentIndexChanged.connect(self.refresh_button)
        form.addRow("图标:", self.icon_combo)

        # 禁用
        self.disable_check = QCheckBox("禁用按钮")
        self.disable_check.stateChanged.connect(self.refresh_button)
        form.addRow("", self.disable_check)

        # 强调
        self.emphasize_check = QCheckBox("强调按钮")
        self.emphasize_check.stateChanged.connect(self.refresh_button)
        form.addRow("", self.emphasize_check)

        # 无边框
        self.flat_check = QCheckBox("无边框")
        self.flat_check.stateChanged.connect(self.refresh_button)
        form.addRow("", self.flat_check)

        # 圆角
        self.round_check = QCheckBox("圆角按钮")
        self.round_check.stateChanged.connect(self.refresh_button)
        form.addRow("", self.round_check)

        # 辉光
        self.glow_check = QCheckBox("辉光按钮")
        self.glow_check.stateChanged.connect(self.refresh_button)
        form.addRow("", self.glow_check)

        self.glow_color_combo = QComboBox()
        self.glow_color_combo.addItems(["#3daee9", "#ff9900", "#00cc66", "#ff3333"])
        self.glow_color_combo.currentIndexChanged.connect(self.refresh_button)
        form.addRow("辉光颜色:", self.glow_color_combo)

        # 链接
        self.link_check = QCheckBox("链接按钮")
        self.link_check.stateChanged.connect(self.refresh_button)
        form.addRow("", self.link_check)

        # 信息级别
        self.level_combo = QComboBox()
        self.level_combo.addItems(["", "info", "success", "warning", "danger", "default"])
        self.level_combo.currentIndexChanged.connect(self.refresh_button)
        form.addRow("信息级别:", self.level_combo)

        # ---------------- 主题设置 ----------------
        theme_group = QGroupBox("主题设置")
        theme_layout = QVBoxLayout(theme_group)

        mode_group = QButtonGroup(self)
        self.auto_radio = QRadioButton("自动"); self.light_radio = QRadioButton("浅色"); self.dark_radio = QRadioButton("深色")
        mode_group.addButton(self.auto_radio,0); mode_group.addButton(self.light_radio,1); mode_group.addButton(self.dark_radio,2)
        mode_h = QHBoxLayout(); mode_h.addWidget(self.auto_radio); mode_h.addWidget(self.light_radio); mode_h.addWidget(self.dark_radio)
        theme_layout.addLayout(mode_h)

        current_mode = ThemeManager.instance().get_theme_mode()
        {ThemeMode.AUTO:self.auto_radio, ThemeMode.LIGHT:self.light_radio, ThemeMode.DARK:self.dark_radio}[current_mode].setChecked(True)
        mode_group.buttonClicked.connect(self._on_mode_changed)

        # 主题颜色
        color_h = QHBoxLayout(); color_h.addWidget(QLabel("主题颜色:"))
        self.color_btn = ForgeButton("选择颜色", flat=True)
        color_h.addWidget(self.color_btn); color_h.addStretch(); theme_layout.addLayout(color_h)
        self.color_btn.clicked.connect(self._choose_color)

        self.layout.addWidget(theme_group)

        # 初始化
        self.refresh_button()

    # ------------------------------------------------------------------
    # 逻辑
    # ------------------------------------------------------------------
    def refresh_button(self):
        """根据表单值更新按钮"""

        # 记录需要进行信号阻塞的控件
        controls_to_block_signals = [
            self.button_type_combo,
            self.emphasize_check,
            self.flat_check,
            self.link_check,
            self.level_combo,
            self.round_check,
            self.glow_check,
            self.disable_check, # disable_check 状态也应在读取最终值前确定
            self.text_edit,     # 文本和图标理论上不参与互斥，但为完整性，在最终读取环节进行
            self.icon_combo,
            self.glow_color_combo
        ]

        # 阻塞信号
        for control in controls_to_block_signals:
            control.blockSignals(True)

        # --- 开始互斥逻辑：直接修改UI控件状态 ---
        # 注意：这里的isCheched()等会读取当前的UI状态
        if self.emphasize_check.isChecked():
            if self.flat_check.isChecked(): self.flat_check.setChecked(False)
            if self.link_check.isChecked(): self.link_check.setChecked(False)
            if self.level_combo.currentIndex() != 0: self.level_combo.setCurrentIndex(0)
            if self.round_check.isChecked(): self.round_check.setChecked(False) # Demo specific
            if self.glow_check.isChecked(): self.glow_check.setChecked(False)    # Demo specific

        if self.flat_check.isChecked(): # 用户勾选 "无边框"
            if self.emphasize_check.isChecked(): self.emphasize_check.setChecked(False)
            if self.link_check.isChecked(): self.link_check.setChecked(False)
            # 无边框 和 信息级别 不在UI层面互斥
            if self.round_check.isChecked(): self.round_check.setChecked(False)
            if self.glow_check.isChecked(): self.glow_check.setChecked(False)

        if self.link_check.isChecked():
            if self.emphasize_check.isChecked(): self.emphasize_check.setChecked(False)
            if self.level_combo.currentIndex() != 0: self.level_combo.setCurrentIndex(0)
            if self.flat_check.isChecked(): self.flat_check.setChecked(False)
            if self.round_check.isChecked(): self.round_check.setChecked(False)
            if self.glow_check.isChecked(): self.glow_check.setChecked(False)

        if self.level_combo.currentIndex() != 0: # 用户选择了一个 "信息级别"
            if self.emphasize_check.isChecked(): self.emphasize_check.setChecked(False)
            if self.link_check.isChecked(): self.link_check.setChecked(False)
            # 信息级别 和 无边框 不在UI层面互斥

        # Toggle button specific conflicts
        if self.button_type_combo.currentText() == "toggle":
            if self.emphasize_check.isChecked(): self.emphasize_check.setChecked(False)
            if self.link_check.isChecked(): self.link_check.setChecked(False)
            if self.level_combo.currentIndex() != 0: self.level_combo.setCurrentIndex(0)
        # --- 互斥逻辑结束 ---

        # 解除信号阻塞
        for control in controls_to_block_signals:
            control.blockSignals(False)

        # --- 在所有UI调整完成后，读取最终的、一致的控件状态 ---
        text = self.text_edit.text()
        icon_name = self.icon_combo.currentData()
        disabled = self.disable_check.isChecked()
        emphasized = self.emphasize_check.isChecked()
        flat = self.flat_check.isChecked()
        rounded = self.round_check.isChecked()
        glow = self.glow_check.isChecked()
        glow_color = self.glow_color_combo.currentText() if glow else None # 仅当glow启用时才有颜色
        link = self.link_check.isChecked()
        level_text = self.level_combo.currentText()
        level = level_text if level_text else None # 如果为空字符串，则为None

        button_type = self.button_type_combo.currentText() or "basic"

        # 若按钮类型有变，则重新创建按钮实例
        # 并且在创建时就传入正确的、经过互斥处理的参数
        current_button_internal_type = getattr(self.preview_button, "_button_type", "basic")
        if button_type != current_button_internal_type:
            parent_layout = self.layout # QVBoxLayout
            if self.preview_button is not None and parent_layout is not None:
                 # 确保在同一个 QVBoxLayout 中进行替换
                current_index = parent_layout.indexOf(self.preview_button)
                if current_index != -1:
                    parent_layout.removeWidget(self.preview_button)
                self.preview_button.deleteLater()


            self.preview_button = ForgeButton(
                text=text,
                icon_name=icon_name or None,
                button_type=button_type,
                emphasized=emphasized,
                flat=flat,
                link=link,
                level=level,
                rounded=rounded,
                glow_color=glow_color
            )
            # 确保 preview_button 始终在第二个位置（索引1），标题之后
            parent_layout.insertWidget(1, self.preview_button, alignment=Qt.AlignmentFlag.AlignCenter)

            # 为 dropdown 或 split 按钮配置菜单
            if button_type in ["dropdown", "split"]:
                from PyQtWidgetForge.common.elements.menu import RoundMenu
                if self.preview_button.menu() is None: # 检查是否已有菜单
                    m = RoundMenu(parent=self.preview_button) # 设置父级
                    for i in range(3):
                        m.addAction(f"选项 {i+1}")
                    self.preview_button.set_menu(m)
        else:
            # 如果类型未变，仅更新属性
            # 从UI控件读取的目标状态 (已在本函数前面通过UI互斥逻辑处理)
            # emphasized, flat, link, level, rounded, glow 是本函数前面定义的布尔/None变量。

            # 设置属性的顺序至关重要，以避免 ForgeButton 的 set 方法抛出 ValueError。
            # UI 互斥逻辑已确保目标变量 (emphasized, flat, link, level, rounded, glow)
            # 根据示例的规则表示一个最终一致的状态。

            # 阶段 1: 设置主要的互斥样式组 (emphasized, link, level, flat)。
            # 其中一个将为 True，或者对于基本按钮全部为 False。
            # 这个顺序确保在激活某个样式时，其冲突样式会首先在按钮实例上被停用。
            if emphasized: # UI目标：emphasized 为 True
                # UI互斥已确保 flat, link, level 的目标都为 False/None
                self.preview_button.set_flat(False)      # 确保按钮实例不是flat
                self.preview_button.set_link(False)      # 确保按钮实例不是link
                self.preview_button.set_level(None)    # 确保按钮实例没有level
                self.preview_button.set_emphasized(True) # 安全设置emphasized
            elif link: # UI目标：link 为 True
                # UI互斥已确保 emphasized, flat, level 的目标都为 False/None
                self.preview_button.set_emphasized(False) # 确保按钮实例不是emphasized
                self.preview_button.set_flat(False)      # 确保按钮实例不是flat
                self.preview_button.set_level(None)    # 确保按钮实例没有level
                self.preview_button.set_link(True)     # 安全设置link
            else: # UI目标：emphasized 和 link 均为 False。此时 level 和 flat 可以组合。
                # 先确保按钮实例的 emphasized 和 link 状态为 False
                self.preview_button.set_emphasized(False)
                self.preview_button.set_link(False)

                # 处理 level 和 flat (这两个现在可以由UI共同指定)
                # 'level' 是从UI读取的目标level值 (字符串或None)
                # 'flat' 是从UI读取的目标flat状态 (布尔值)
                if level is not None:
                    self.preview_button.set_level(level) # 应用level。ForgeButton内部会将_flat设为False。
                    if flat: # 如果UI同时要求flat为True
                        self.preview_button.set_flat(True) # 在set_level之后，将按钮设为flat。_level状态会保留。
                    # else: 如果UI不要求flat (flat为False)，set_level已使按钮非flat，无需额外操作。
                else: # UI目标：level 为 None
                    self.preview_button.set_level(None)
                    # 此时，按钮的最终flat状态完全由UI的flat目标状态决定。
                    self.preview_button.set_flat(flat)

            # 阶段 2: 设置其他属性，如 rounded 和 glow。
            # 这些与 flat 和 link 冲突。UI 互斥逻辑确保如果 rounded 或 glow 为 True，
            # 那么 flat 和 link 的目标状态是 False。
            # 上面的代码块已经相应地设置了按钮内部的 _flat 和 _link 状态。
            self.preview_button.set_rounded(rounded)
            self.preview_button.set_glow_color(glow_color) # 如果 glow 的目标状态是 False，则 glow_color 为 None

            # 设置文本和图标
            self.preview_button.setText(text)
            if icon_name:
                self.preview_button.set_icon_name(icon_name)
            else:
                self.preview_button.set_icon_name(None) # 确保可以清除图标

        # Dropdown / Split 类型需要配置菜单
        if button_type in ["dropdown", "split"]:
            from PyQtWidgetForge.common.elements.menu import RoundMenu
            if self.preview_button.menu() is None: # 检查是否已有菜单
                m = RoundMenu(parent=self.preview_button) # 设置父级
                for i in range(3):
                    m.addAction(f"选项 {i+1}")
                self.preview_button.set_menu(m)

        # 启用状态 (这个应该在属性设置之后，或者不影响其他属性即可)
        self.preview_button.setEnabled(not disabled)
        
        # 注意：原有的互斥逻辑块现在已经被移到前面，并直接作用于UI控件。
        # 因此，这里不再需要原有的位于末尾的互斥逻辑块。

    # 主题切换
    def _on_mode_changed(self, button):
        if button==self.auto_radio:
            ThemeManager.instance().set_theme_mode(ThemeMode.AUTO)
        elif button==self.light_radio:
            ThemeManager.instance().set_theme_mode(ThemeMode.LIGHT)
        else:
            ThemeManager.instance().set_theme_mode(ThemeMode.DARK)

    def _choose_color(self):
        from PyQt6.QtWidgets import QColorDialog
        tm = ThemeManager.instance()
        col = QColorDialog.getColor(tm.get_theme_color(), self, "选择主题颜色")
        if col.isValid():
            tm.set_theme_color(col)


# ----------------------------------------------------------------------
# 启动脚本
# ----------------------------------------------------------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    demo = ButtonDemo()
    demo.show()
    sys.exit(app.exec())
