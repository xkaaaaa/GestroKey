# PyQtWidgetForge

PyQtWidgetForge是一个基于PyQt6的组件库，提供一系列可重用的自定义组件和控件。

## 安装

```bash
# 克隆仓库
git clone https://github.com/xkaaaaa/PyQtWidgetForge.git

# 进入项目目录
cd PyQtWidgetForge

# 以开发模式安装
pip install -e .
```

## 特性

- 提供多种自定义的PyQt6组件
- 使用简单，易于集成
- 设计美观，符合现代UI设计风格
- 提供中文文档和示例

## 使用示例

```python
from PyQt6.QtWidgets import QApplication
from PyQtWidgetForge import VERSION

# 输出版本信息
print(f"当前使用的PyQtWidgetForge版本: {VERSION}")

# 后续会添加组件使用示例
```

## 许可证

GPL-3.0